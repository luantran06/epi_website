"""
Data Preprocessing for BRFSS 2024 Diabetes Analysis

This script cleans the LLCP2024.csv data by:
1. Handling special codes (7=Don't Know, 9=Refused)
2. Creating clean outcome variables
3. Recoding categorical variables
4. Creating analysis-ready datasets
"""

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

def load_data(filepath='LLCP2024.csv'):
    """Load BRFSS 2024 data"""
    print("Loading BRFSS 2024 data...")
    df = pd.read_csv(filepath)
    print(f"Data loaded: {df.shape[0]:,} observations, {df.shape[1]} variables")
    return df

def handle_special_codes(df):
    """
    Replace BRFSS special codes with NaN
    7, 77, 777 = Don't know/Not sure
    9, 99, 999 = Refused
    """
    print("\nHandling special codes (7=Don't Know, 9=Refused)...")

    # Define special codes to replace with NaN
    special_codes = [7, 9, 77, 99, 777, 999]

    # Count how many values will be replaced
    total_replaced = 0
    for code in special_codes:
        total_replaced += (df == code).sum().sum()

    # Replace with NaN
    df_clean = df.replace(special_codes, np.nan)

    print(f"Replaced {total_replaced:,} special code values with NaN")
    return df_clean

def create_outcome_variables(df):
    """Create clean diabetes outcome variables"""
    print("\nCreating outcome variables...")

    # Main binary outcome: has_diabetes
    # 1 = Yes (diabetes), 0 = No
    # Exclude: 2=gestational, 4=prediabetes, 7=DK, 9=refused
    def categorize_diabetes_binary(x):
        if x == 1:
            return 1  # Diabetes
        elif x == 3:
            return 0  # No diabetes
        else:
            return np.nan  # Exclude others

    df['has_diabetes'] = df['DIABETE4'].apply(categorize_diabetes_binary)

    # Categorical outcome for exploration
    def categorize_diabetes_full(x):
        if x == 1:
            return 'Diabetes'
        elif x == 2:
            return 'Gestational'
        elif x == 3:
            return 'No Diabetes'
        elif x == 4:
            return 'Prediabetes'
        else:
            return np.nan

    df['diabetes_status'] = df['DIABETE4'].apply(categorize_diabetes_full)

    diabetes_counts = df['has_diabetes'].value_counts()
    print(f"Diabetes cases: {diabetes_counts.get(1, 0):,}")
    print(f"No diabetes cases: {diabetes_counts.get(0, 0):,}")
    print(f"Excluded/missing: {df['has_diabetes'].isna().sum():,}")

    return df

def recode_demographics(df):
    """Recode demographic variables with meaningful labels"""
    print("\nRecoding demographic variables...")

    # Sex
    sex_map = {1: 'Male', 2: 'Female'}
    df['sex'] = df['_SEX'].map(sex_map)

    # Age groups
    age_map = {
        1: '18-24', 2: '25-34', 3: '35-44',
        4: '45-54', 5: '55-64', 6: '65+'
    }
    df['age_group'] = df['_AGE_G'].map(age_map)

    # Race/ethnicity
    race_map = {
        1: 'White', 2: 'Black', 3: 'Native American',
        4: 'Asian', 5: 'Pacific Islander', 6: 'Other',
        7: 'Multiracial', 8: 'Hispanic'
    }
    df['race'] = df['_RACE'].map(race_map)

    # Income
    income_map = {
        1: '<$15k', 2: '$15k-$25k', 3: '$25k-$35k',
        4: '$35k-$50k', 5: '$50k-$100k', 6: '$100k-$200k',
        7: '>$200k'
    }
    df['income_group'] = df['_INCOMG1'].map(income_map)

    # Education
    educ_map = {
        1: 'No HS', 2: 'Some HS',
        3: 'HS Grad', 4: 'Some College+'
    }
    df['education'] = df['_EDUCAG'].map(educ_map)

    # BMI categories
    bmi_map = {
        1: 'Underweight', 2: 'Normal',
        3: 'Overweight', 4: 'Obese'
    }
    df['bmi_category'] = df['_BMI5CAT'].map(bmi_map)

    # Convert BMI to actual value (stored as BMI*100)
    if '_BMI5' in df.columns:
        df['bmi_actual'] = df['_BMI5'] / 100

    # General health
    health_map = {
        1: 'Excellent', 2: 'Very good', 3: 'Good',
        4: 'Fair', 5: 'Poor'
    }
    df['general_health'] = df['GENHLTH'].map(health_map)

    print("Demographics recoded successfully")
    return df

def recode_mental_health(df):
    """Recode mental health variables"""
    print("\nRecoding mental health variables...")

    # Depression
    depression_map = {1: 'Yes', 2: 'No'}
    df['has_depression'] = df['ADDEPEV3'].map(depression_map)

    # Mental health days - create categories
    def categorize_mental_health_days(x):
        if pd.isna(x):
            return np.nan
        elif x == 88:  # None
            return '0 days'
        elif x <= 5:
            return '1-5 days'
        elif x <= 13:
            return '6-13 days'
        elif x <= 30:
            return '14-30 days'
        else:
            return np.nan

    df['mental_health_days_cat'] = df['MENTHLTH'].apply(categorize_mental_health_days)

    # Loneliness
    loneliness_map = {
        1: 'Always', 2: 'Usually', 3: 'Sometimes',
        4: 'Rarely', 5: 'Never'
    }
    df['loneliness'] = df['SDLONELY'].map(loneliness_map)

    # Life satisfaction
    satisfaction_map = {
        1: 'Very satisfied', 2: 'Satisfied',
        3: 'Dissatisfied', 4: 'Very dissatisfied'
    }
    df['life_satisfaction'] = df['LSATISFY'].map(satisfaction_map)

    # Emotional support
    support_map = {
        1: 'Always', 2: 'Usually', 3: 'Sometimes',
        4: 'Rarely', 5: 'Never'
    }
    df['emotional_support'] = df['EMTSUPRT'].map(support_map)

    print("Mental health variables recoded successfully")
    return df

def recode_sdoh(df):
    """Recode Social Determinants of Health variables"""
    print("\nRecoding SDOH variables...")

    # Food insecurity
    food_map = {
        1: 'Always worried', 2: 'Usually worried',
        3: 'Sometimes worried', 4: 'Rarely worried',
        5: 'Never worried'
    }
    df['food_insecurity'] = df['SDHFOOD1'].map(food_map)

    # Bill payment confidence
    bills_map = {
        1: 'Very confident', 2: 'Somewhat confident',
        3: 'Not very confident', 4: 'Not confident at all'
    }
    df['bills_confidence'] = df['SDHBILLS'].map(bills_map)

    # Transportation barriers
    transport_map = {1: 'Yes - lack transport', 2: 'No - have transport'}
    df['lacks_transport'] = df['SDHTRNSP'].map(transport_map)

    # SNAP/Food stamps
    snap_map = {1: 'Yes - received SNAP', 2: 'No'}
    df['received_snap'] = df['FOODSTMP'].map(snap_map)

    # Employment
    employ_map = {1: 'Yes', 2: 'No'}
    df['employed_past_year'] = df['SDHEMPLY'].map(employ_map)

    print("SDOH variables recoded successfully")
    return df

def recode_healthcare_access(df):
    """Recode healthcare access variables"""
    print("\nRecoding healthcare access variables...")

    # Cost barrier
    cost_map = {1: 'Yes - cost barrier', 2: 'No cost barrier'}
    df['cost_barrier'] = df['MEDCOST1'].map(cost_map)

    # Personal doctor
    doctor_map = {
        1: 'Yes, only one', 2: 'More than one',
        3: 'No personal doctor'
    }
    df['has_doctor'] = df['PERSDOC3'].map(doctor_map)

    # Health insurance
    insurance_map = {1: 'Yes - insured', 2: 'No - uninsured'}
    df['has_insurance'] = df['_HLTHPL2'].map(insurance_map)

    # Last checkup
    checkup_map = {
        1: 'Within past year', 2: '1-2 years ago',
        3: '2-5 years ago', 4: '5+ years ago',
        8: 'Never'
    }
    df['last_checkup'] = df['CHECKUP1'].map(checkup_map)

    print("Healthcare access variables recoded successfully")
    return df

def recode_lifestyle(df):
    """Recode lifestyle variables"""
    print("\nRecoding lifestyle variables...")

    # Exercise
    exercise_map = {1: 'Yes', 2: 'No'}
    df['exercises'] = df['EXERANY2'].map(exercise_map)

    # Smoking
    smoking_map = {
        1: 'Current daily', 2: 'Current some days',
        3: 'Former smoker', 4: 'Never smoked'
    }
    df['smoking_status'] = df['_SMOKER3'].map(smoking_map)

    print("Lifestyle variables recoded successfully")
    return df

def create_analysis_datasets(df):
    """Create different analysis-ready datasets"""
    print("\n" + "="*80)
    print("Creating analysis datasets...")
    print("="*80)

    # Dataset 1: Traditional factors only
    traditional_vars = [
        'has_diabetes', 'diabetes_status',
        'bmi_category', 'bmi_actual', 'age_group', 'sex', 'race',
        'income_group', 'education', 'general_health',
        'exercises', 'smoking_status',
        '_AGE_G', '_SEX', '_RACE', '_BMI5CAT', '_INCOMG1', '_EDUCAG'
    ]
    df_traditional = df[traditional_vars].copy()
    n_traditional = df_traditional.dropna(subset=['has_diabetes']).shape[0]
    print(f"\n1. Traditional factors dataset: {n_traditional:,} observations")

    # Dataset 2: Traditional + Mental Health
    mental_vars = traditional_vars + [
        'has_depression', 'MENTHLTH', 'mental_health_days_cat',
        'loneliness', 'life_satisfaction', 'emotional_support',
        'ADDEPEV3', 'SDLONELY', 'LSATISFY', 'EMTSUPRT'
    ]
    df_mental = df[[v for v in mental_vars if v in df.columns]].copy()
    n_mental = df_mental.dropna(subset=['has_diabetes', 'has_depression']).shape[0]
    print(f"2. Traditional + Mental Health dataset: {n_mental:,} observations")

    # Dataset 3: Traditional + SDOH
    sdoh_vars = traditional_vars + [
        'food_insecurity', 'bills_confidence', 'lacks_transport',
        'received_snap', 'employed_past_year',
        'SDHFOOD1', 'SDHBILLS', 'SDHTRNSP', 'FOODSTMP', 'SDHEMPLY'
    ]
    df_sdoh = df[[v for v in sdoh_vars if v in df.columns]].copy()
    n_sdoh = df_sdoh.dropna(subset=['has_diabetes', 'food_insecurity']).shape[0]
    print(f"3. Traditional + SDOH dataset: {n_sdoh:,} observations")

    # Dataset 4: Traditional + Healthcare Access
    healthcare_vars = traditional_vars + [
        'cost_barrier', 'has_doctor', 'has_insurance', 'last_checkup',
        'MEDCOST1', 'PERSDOC3', '_HLTHPL2', 'CHECKUP1'
    ]
    df_healthcare = df[[v for v in healthcare_vars if v in df.columns]].copy()
    n_healthcare = df_healthcare.dropna(subset=['has_diabetes', 'cost_barrier']).shape[0]
    print(f"4. Traditional + Healthcare Access dataset: {n_healthcare:,} observations")

    # Dataset 5: Full model (all variables)
    all_vars = list(set(traditional_vars + mental_vars + sdoh_vars + healthcare_vars))
    df_full = df[[v for v in all_vars if v in df.columns]].copy()
    n_full = df_full.dropna(subset=[
        'has_diabetes', 'bmi_category', 'age_group',
        'has_depression', 'food_insecurity', 'cost_barrier'
    ]).shape[0]
    print(f"5. Full model dataset: {n_full:,} observations")

    return {
        'full': df,
        'traditional': df_traditional,
        'mental': df_mental,
        'sdoh': df_sdoh,
        'healthcare': df_healthcare,
        'full_model': df_full
    }

def save_datasets(datasets, output_dir='./'):
    """Save cleaned datasets to CSV files"""
    print("\n" + "="*80)
    print("Saving datasets...")
    print("="*80)

    # Save full cleaned dataset
    datasets['full'].to_csv(f'{output_dir}LLCP2024_cleaned.csv', index=False)
    print(f" Saved: LLCP2024_cleaned.csv ({datasets['full'].shape[0]:,} rows)")

    # Save analysis subsets
    datasets['traditional'].to_csv(f'{output_dir}data_traditional.csv', index=False)
    print(f" Saved: data_traditional.csv ({datasets['traditional'].shape[0]:,} rows)")

    datasets['mental'].to_csv(f'{output_dir}data_mental_health.csv', index=False)
    print(f" Saved: data_mental_health.csv ({datasets['mental'].shape[0]:,} rows)")

    datasets['sdoh'].to_csv(f'{output_dir}data_sdoh.csv', index=False)
    print(f" Saved: data_sdoh.csv ({datasets['sdoh'].shape[0]:,} rows)")

    datasets['healthcare'].to_csv(f'{output_dir}data_healthcare.csv', index=False)
    print(f" Saved: data_healthcare.csv ({datasets['healthcare'].shape[0]:,} rows)")

    datasets['full_model'].to_csv(f'{output_dir}data_full_model.csv', index=False)
    print(f" Saved: data_full_model.csv ({datasets['full_model'].shape[0]:,} rows)")

    print("\n All datasets saved successfully!")

def main():
    """Main preprocessing pipeline"""
    print("="*80)
    print("BRFSS 2024 DATA PREPROCESSING PIPELINE")
    print("="*80)

    # 1. Load data
    df = load_data('LLCP2024.csv')

    # 2. Handle special codes
    df = handle_special_codes(df)

    # 3. Create outcome variables
    df = create_outcome_variables(df)

    # 4. Recode all variables
    df = recode_demographics(df)
    df = recode_mental_health(df)
    df = recode_sdoh(df)
    df = recode_healthcare_access(df)
    df = recode_lifestyle(df)

    # 5. Create analysis datasets
    datasets = create_analysis_datasets(df)

    # 6. Save datasets
    save_datasets(datasets)

    print("\n" + "="*80)
    print("PREPROCESSING COMPLETE!")
    print("="*80)
    print("\nYou can now proceed with EDA using the cleaned datasets:")
    print("  - LLCP2024_cleaned.csv (full dataset)")
    print("  - data_traditional.csv (traditional risk factors)")
    print("  - data_mental_health.csv (+ mental health)")
    print("  - data_sdoh.csv (+ social determinants)")
    print("  - data_healthcare.csv (+ healthcare access)")
    print("  - data_full_model.csv (all variables)")

    return datasets

if __name__ == "__main__":
    datasets = main()
