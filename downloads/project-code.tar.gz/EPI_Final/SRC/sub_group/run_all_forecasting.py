"""
Master Script: Run Complete Forecasting Pipeline (ENHANCED)

This script orchestrates all forecasting analyses:
1. Main forecasting pipeline (7 methods)
2. Advanced methods (Prophet, ARIMA, Ensemble) [ENHANCED]
   - Ridge regularization + linear blending for stability
   - ARIMA with saturation constraint (plateau + decline)
   - Inverse-MAE weighted ensemble (automatic optimization)
   - Residual-based confidence intervals (properly centered)
3. Visualizations (8 plots + dashboard)
4. Insights report generation

Usage: python run_all_forecasting.py

Author: Diabetes Risk Analysis Project
"""

import subprocess
import os
import time
from datetime import datetime

# Get the directory where this script is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

print("="*80)
print("MASTER FORECASTING PIPELINE")
print("Comprehensive Age-Based Diabetes Risk Analysis")
print("="*80)
print(f"\nStart time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"Working directory: {SCRIPT_DIR}")

# Change to script directory to ensure all files are accessible
os.chdir(SCRIPT_DIR)

# Track execution time
start_time = time.time()

# ============================================================================
# STEP 1: Run Main Forecasting Pipeline
# ============================================================================

print("\n" + "="*80)
print("STEP 1/3: Running Main Forecasting Pipeline")
print("="*80)

try:
    result = subprocess.run(
        ['python', 'forecasting_pipeline.py'],
        capture_output=True,
        text=True,
        timeout=600
    )
    print(result.stdout)
    if result.returncode != 0:
        print(f"ERROR: {result.stderr}")
        raise Exception("Main pipeline failed")
    print("\n✓ Main forecasting pipeline completed successfully")
except Exception as e:
    print(f"\n✗ Main pipeline failed: {e}")
    print("Continuing with next steps...")

time.sleep(1)

# ============================================================================
# STEP 2: Run Advanced Forecasting Methods
# ============================================================================

print("\n" + "="*80)
print("STEP 2/3: Running Advanced Forecasting Methods")
print("="*80)

try:
    result = subprocess.run(
        ['python', 'advanced_forecasting.py'],
        capture_output=True,
        text=True,
        timeout=600
    )
    print(result.stdout)
    if result.returncode != 0:
        print(f"ERROR: {result.stderr}")
        raise Exception("Advanced methods failed")
    print("\n✓ Advanced forecasting methods completed successfully")
except Exception as e:
    print(f"\n✗ Advanced methods failed: {e}")
    print("Continuing with next steps...")

time.sleep(1)

# ============================================================================
# STEP 3: Generate All Visualizations
# ============================================================================

print("\n" + "="*80)
print("STEP 3/3: Generating Visualizations")
print("="*80)

try:
    result = subprocess.run(
        ['python', 'forecasting_visualizations.py'],
        capture_output=True,
        text=True,
        timeout=600
    )
    print(result.stdout)
    if result.returncode != 0:
        print(f"ERROR: {result.stderr}")
        raise Exception("Visualization generation failed")
    print("\n✓ Visualizations generated successfully")
except Exception as e:
    print(f"\n✗ Visualization generation failed: {e}")

# ============================================================================
# SUMMARY AND REPORT
# ============================================================================

end_time = time.time()
execution_time = end_time - start_time

print("\n" + "="*80)
print("PIPELINE EXECUTION COMPLETE")
print("="*80)

print(f"\nTotal execution time: {execution_time/60:.2f} minutes")
print(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

# Check which files were generated
expected_csvs = [
    'forecast_age_prevalence.csv',
    'forecast_future_prevalence.csv',
    'forecast_feature_importance_by_age.csv',
    'forecast_cohort_trajectories.csv',
    'forecast_trajectory_predictions.csv',
    'forecast_survival_curves.csv',
    'forecast_transfer_learning_results.csv',
    'forecast_timeseries_predictions.csv',
    'forecast_advanced_ensemble.csv',
    'forecast_model_comparison.csv'
]

expected_pngs = [
    'viz_age_progression_forecast.png',
    'viz_feature_importance_evolution.png',
    'viz_feature_importance_trends.png',
    'viz_cohort_trajectories.png',
    'viz_survival_curves.png',
    'viz_transfer_learning.png',
    'viz_timeseries_forecast.png',
    'viz_comprehensive_dashboard.png',
    'viz_advanced_forecasting.png'
]

print("\n" + "-"*80)
print("Generated Files:")
print("-"*80)

csv_count = 0
for csv_file in expected_csvs:
    if os.path.exists(csv_file):
        size_kb = os.path.getsize(csv_file) / 1024
        print(f"  ✓ {csv_file:50s} ({size_kb:6.1f} KB)")
        csv_count += 1
    else:
        print(f"  ✗ {csv_file:50s} (NOT FOUND)")

print()
png_count = 0
for png_file in expected_pngs:
    if os.path.exists(png_file):
        size_kb = os.path.getsize(png_file) / 1024
        print(f"  ✓ {png_file:50s} ({size_kb:6.1f} KB)")
        png_count += 1
    else:
        print(f"  ✗ {png_file:50s} (NOT FOUND)")

print("\n" + "-"*80)
print(f"Summary: {csv_count}/{len(expected_csvs)} CSV files, {png_count}/{len(expected_pngs)} PNG files generated")
print("-"*80)

print("\n" + "="*80)
print("NEXT STEPS")
print("="*80)
print("""
1. Review visualizations:
   - Open viz_comprehensive_dashboard.png for overview
   - Check viz_advanced_forecasting.png for enhanced ensemble methods

2. Analyze CSV outputs:
   - forecast_model_comparison.csv shows best forecasting method (Ensemble!)
   - forecast_advanced_ensemble.csv contains weighted predictions with CI
   - forecast_transfer_learning_results.csv shows cross-age accuracy

3. Enhanced forecasting features:
   - Ridge regularization + linear blending for stability
   - ARIMA with saturation constraint (shows decline at extreme ages)
   - Inverse-MAE weighting (automatic optimal ensemble)
   - Residual-based confidence intervals (properly centered)

4. Key questions to explore:
   - Which risk factors become more important with age?
   - Do income-based trajectories diverge over time? (21-fold gap!)
   - Can we predict elderly diabetes risk from middle-age data? (AUC 0.75)

5. For publication:
   - Extract key statistics from CSVs
   - Use viz_comprehensive_dashboard.png as Figure 1
   - Report ensemble forecast with 95% CI (e.g., Age 80: 24.0% [23.3%, 24.8%])
   - Cite model comparison: Ensemble best (MAE=0.012)
""")

print("="*80)
