"""
Comprehensive Visualization Suite for Forecasting Analysis

Generates all visualizations for the forecasting pipeline including:
- Age progression curves
- Risk factor evolution heatmaps
- Cohort trajectory plots
- Survival curves
- Transfer learning performance
- Time-series forecasts

Author: Diabetes Risk Analysis Project
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.gridspec import GridSpec
import warnings
warnings.filterwarnings('ignore')

# Set visualization style
sns.set_style("whitegrid")
sns.set_palette("husl")
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.size'] = 10

print("="*80)
print("FORECASTING VISUALIZATION SUITE")
print("="*80)

# ============================================================================
# VIZ 1: AGE PROGRESSION - DIABETES PREVALENCE
# ============================================================================

print("\n[1/8] Creating age progression prevalence plot...")

# Load data
prevalence = pd.read_csv('forecast_age_prevalence.csv')
forecast = pd.read_csv('forecast_future_prevalence.csv')

fig, ax = plt.subplots(figsize=(12, 7))

# Plot observed prevalence
ax.plot(prevalence['age_numeric'], prevalence['prevalence'] * 100,
        'o-', markersize=10, linewidth=2.5, label='Observed Data',
        color='#2E86AB', markeredgecolor='white', markeredgewidth=2)

# Plot forecasted prevalence
ax.plot(forecast['age'], forecast['forecasted_prevalence'] * 100,
        's--', markersize=8, linewidth=2, label='Forecasted',
        color='#A23B72', alpha=0.8)

# Add confidence interval (simple simulation)
forecast_std = np.std(prevalence['prevalence']) * 100
ax.fill_between(forecast['age'],
                 forecast['forecasted_prevalence'] * 100 - 1.96 * forecast_std,
                 forecast['forecasted_prevalence'] * 100 + 1.96 * forecast_std,
                 alpha=0.2, color='#A23B72', label='95% CI')

ax.set_xlabel('Age (years)', fontsize=12, fontweight='bold')
ax.set_ylabel('Diabetes Prevalence (%)', fontsize=12, fontweight='bold')
ax.set_title('Age Progression Forecasting: Diabetes Prevalence Trends',
             fontsize=14, fontweight='bold', pad=20)
ax.legend(fontsize=11, framealpha=0.9)
ax.grid(True, alpha=0.3)
ax.set_xlim(15, 85)

plt.tight_layout()
plt.savefig('viz_age_progression_forecast.png', bbox_inches='tight')
print("  ✓ Saved: viz_age_progression_forecast.png")
plt.close()

# ============================================================================
# VIZ 2: FEATURE IMPORTANCE EVOLUTION HEATMAP
# ============================================================================

print("[2/8] Creating feature importance evolution heatmap...")

importance = pd.read_csv('forecast_feature_importance_by_age.csv')

# Pivot to matrix format
importance_pivot = importance.pivot(index='feature', columns='age_group', values='importance')

# Sort by total importance
importance_pivot['total'] = importance_pivot.sum(axis=1)
importance_pivot = importance_pivot.sort_values('total', ascending=False).drop('total', axis=1)

# Reorder columns by age
age_order = ['18-24', '25-34', '35-44', '45-54', '55-64', '65+']
importance_pivot = importance_pivot[[col for col in age_order if col in importance_pivot.columns]]

# Take top 15 features
importance_pivot_top = importance_pivot.head(15)

fig, ax = plt.subplots(figsize=(14, 10))

sns.heatmap(importance_pivot_top, annot=True, fmt='.3f', cmap='YlOrRd',
            cbar_kws={'label': 'Feature Importance'},
            linewidths=0.5, linecolor='gray', ax=ax)

ax.set_xlabel('Age Group', fontsize=12, fontweight='bold')
ax.set_ylabel('Risk Factor', fontsize=12, fontweight='bold')
ax.set_title('Risk Factor Importance Evolution Across Age Groups',
             fontsize=14, fontweight='bold', pad=20)

plt.tight_layout()
plt.savefig('viz_feature_importance_evolution.png', bbox_inches='tight')
print("  ✓ Saved: viz_feature_importance_evolution.png")
plt.close()

# ============================================================================
# VIZ 3: FEATURE IMPORTANCE TRENDS (LINE PLOT)
# ============================================================================

print("[3/8] Creating feature importance trend lines...")

# Select top 8 features for clarity
top_features = importance_pivot.sum(axis=1).sort_values(ascending=False).head(8).index

fig, ax = plt.subplots(figsize=(14, 8))

for feature in top_features:
    feature_data = importance[importance['feature'] == feature].sort_values('age_numeric')
    ax.plot(feature_data['age_numeric'], feature_data['importance'],
            'o-', markersize=8, linewidth=2.5, label=feature, alpha=0.8)

ax.set_xlabel('Age (years)', fontsize=12, fontweight='bold')
ax.set_ylabel('Feature Importance Score', fontsize=12, fontweight='bold')
ax.set_title('How Risk Factor Importance Changes with Age',
             fontsize=14, fontweight='bold', pad=20)
ax.legend(fontsize=10, loc='best', framealpha=0.9, ncol=2)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('viz_feature_importance_trends.png', bbox_inches='tight')
print("  ✓ Saved: viz_feature_importance_trends.png")
plt.close()

# ============================================================================
# VIZ 4: COHORT TRAJECTORY PLOT (Age × Income)
# ============================================================================

print("[4/8] Creating cohort trajectory plots...")

trajectories = pd.read_csv('forecast_cohort_trajectories.csv')
traj_forecast = pd.read_csv('forecast_trajectory_predictions.csv')

fig, ax = plt.subplots(figsize=(14, 8))

# Plot observed trajectories
income_colors = {
    '<$15k': '#D62828', '$15k-$25k': '#F77F00',
    '$25k-$35k': '#FCBF49', '$35k-$50k': '#EAE2B7',
    '$50k-$100k': '#06AED5', '$100k-$200k': '#0353A4',
    '>$200k': '#023E7D'
}

for income in trajectories['income_group'].unique():
    traj_data = trajectories[trajectories['income_group'] == income].sort_values('age_numeric')
    color = income_colors.get(income, '#000000')

    ax.plot(traj_data['age_numeric'], traj_data['diabetes_rate'] * 100,
            'o-', markersize=8, linewidth=2.5, label=f'{income} (Observed)',
            color=color, alpha=0.9)

    # Add forecasted trajectories
    traj_fc = traj_forecast[traj_forecast['income_group'] == income]
    if len(traj_fc) > 0:
        ax.plot(traj_fc['age'], traj_fc['forecasted_diabetes_rate'] * 100,
                's--', markersize=6, linewidth=1.5, alpha=0.5, color=color)

ax.set_xlabel('Age (years)', fontsize=12, fontweight='bold')
ax.set_ylabel('Diabetes Prevalence (%)', fontsize=12, fontweight='bold')
ax.set_title('Cohort Trajectory Forecasting by Income Level',
             fontsize=14, fontweight='bold', pad=20)
ax.legend(fontsize=9, loc='upper left', framealpha=0.9, ncol=2)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('viz_cohort_trajectories.png', bbox_inches='tight')
print("  ✓ Saved: viz_cohort_trajectories.png")
plt.close()

# ============================================================================
# VIZ 5: SURVIVAL CURVES
# ============================================================================

print("[5/8] Creating survival curve plots...")

survival = pd.read_csv('forecast_survival_curves.csv')

# Plot survival curves for selected subgroups
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))

# Panel 1: By sex
for sex in survival['sex'].unique():
    surv_sex = survival[survival['sex'] == sex].groupby('age')['survival_prob'].mean().reset_index()
    ax1.plot(surv_sex['age'], surv_sex['survival_prob'] * 100,
             'o-', markersize=8, linewidth=2.5, label=sex, alpha=0.8)

ax1.set_xlabel('Age (years)', fontsize=11, fontweight='bold')
ax1.set_ylabel('Diabetes-Free Survival (%)', fontsize=11, fontweight='bold')
ax1.set_title('Survival Curves by Sex', fontsize=12, fontweight='bold')
ax1.legend(fontsize=10)
ax1.grid(True, alpha=0.3)
ax1.set_ylim(0, 105)

# Panel 2: By income (top 4 groups)
income_order = ['<$15k', '$15k-$25k', '$50k-$100k', '>$200k']
for income in income_order:
    surv_income = survival[survival['income_group'] == income].groupby('age')['survival_prob'].mean().reset_index()
    if len(surv_income) > 0:
        ax2.plot(surv_income['age'], surv_income['survival_prob'] * 100,
                 'o-', markersize=8, linewidth=2.5, label=income, alpha=0.8)

ax2.set_xlabel('Age (years)', fontsize=11, fontweight='bold')
ax2.set_ylabel('Diabetes-Free Survival (%)', fontsize=11, fontweight='bold')
ax2.set_title('Survival Curves by Income Level', fontsize=12, fontweight='bold')
ax2.legend(fontsize=10)
ax2.grid(True, alpha=0.3)
ax2.set_ylim(0, 105)

plt.tight_layout()
plt.savefig('viz_survival_curves.png', bbox_inches='tight')
print("  ✓ Saved: viz_survival_curves.png")
plt.close()

# ============================================================================
# VIZ 6: TRANSFER LEARNING PERFORMANCE
# ============================================================================

print("[6/8] Creating transfer learning performance plot...")

transfer = pd.read_csv('forecast_transfer_learning_results.csv')

fig, ax = plt.subplots(figsize=(12, 7))

# Create transition labels
transfer['transition'] = transfer['source_age'] + ' → ' + transfer['target_age']

# Plot AUC scores
bars = ax.bar(range(len(transfer)), transfer['auc_score'],
               color=plt.cm.viridis(transfer['auc_score']),
               edgecolor='black', linewidth=1.5, alpha=0.8)

# Add value labels
for i, (idx, row) in enumerate(transfer.iterrows()):
    ax.text(i, row['auc_score'] + 0.01, f"{row['auc_score']:.3f}",
            ha='center', fontsize=10, fontweight='bold')

ax.set_xticks(range(len(transfer)))
ax.set_xticklabels(transfer['transition'], rotation=45, ha='right')
ax.set_ylabel('AUC Score', fontsize=12, fontweight='bold')
ax.set_title('Transfer Learning: Cross-Age Prediction Performance',
             fontsize=14, fontweight='bold', pad=20)
ax.axhline(y=0.5, color='red', linestyle='--', linewidth=2, alpha=0.5, label='Random Guess')
ax.axhline(y=0.7, color='orange', linestyle='--', linewidth=2, alpha=0.5, label='Good Performance')
ax.legend(fontsize=10)
ax.set_ylim(0, 1)
ax.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('viz_transfer_learning.png', bbox_inches='tight')
print("  ✓ Saved: viz_transfer_learning.png")
plt.close()

# ============================================================================
# VIZ 7: TIME-SERIES FORECAST
# ============================================================================

print("[7/8] Creating time-series forecast visualization...")

ts_forecast = pd.read_csv('forecast_timeseries_predictions.csv')
prevalence_actual = pd.read_csv('forecast_age_prevalence.csv')

fig, ax = plt.subplots(figsize=(12, 7))

# Plot historical data
ax.plot(prevalence_actual['age_numeric'], prevalence_actual['prevalence'] * 100,
        'o-', markersize=10, linewidth=2.5, label='Historical Data',
        color='#2E86AB', markeredgecolor='white', markeredgewidth=2)

# Plot forecast
ax.plot(ts_forecast['age'], ts_forecast['forecasted_prevalence'] * 100,
        's--', markersize=8, linewidth=2, label='Time-Series Forecast',
        color='#F18F01', alpha=0.8)

# Shade forecast region
ax.axvspan(73, 95, alpha=0.1, color='orange', label='Forecast Period')

ax.set_xlabel('Age (years)', fontsize=12, fontweight='bold')
ax.set_ylabel('Diabetes Prevalence (%)', fontsize=12, fontweight='bold')
ax.set_title('Time-Series Forecasting: Extended Age Projections',
             fontsize=14, fontweight='bold', pad=20)
ax.legend(fontsize=11, framealpha=0.9)
ax.grid(True, alpha=0.3)
ax.set_xlim(15, 95)

plt.tight_layout()
plt.savefig('viz_timeseries_forecast.png', bbox_inches='tight')
print("  ✓ Saved: viz_timeseries_forecast.png")
plt.close()

# ============================================================================
# VIZ 8: COMPREHENSIVE DASHBOARD
# ============================================================================

print("[8/8] Creating comprehensive dashboard...")

fig = plt.figure(figsize=(20, 16))
gs = GridSpec(3, 2, figure=fig, hspace=0.3, wspace=0.3)

# Panel 1: Age progression
ax1 = fig.add_subplot(gs[0, 0])
ax1.plot(prevalence['age_numeric'], prevalence['prevalence'] * 100,
         'o-', markersize=8, linewidth=2.5, color='#2E86AB')
ax1.plot(forecast['age'], forecast['forecasted_prevalence'] * 100,
         's--', markersize=6, linewidth=2, color='#A23B72')
ax1.set_xlabel('Age (years)', fontweight='bold')
ax1.set_ylabel('Diabetes Prevalence (%)', fontweight='bold')
ax1.set_title('A. Age Progression Forecast', fontweight='bold', loc='left')
ax1.grid(True, alpha=0.3)

# Panel 2: Top features by age
ax2 = fig.add_subplot(gs[0, 1])
top_3_features = importance_pivot.sum(axis=1).sort_values(ascending=False).head(3).index
for feature in top_3_features:
    feature_data = importance[importance['feature'] == feature].sort_values('age_numeric')
    ax2.plot(feature_data['age_numeric'], feature_data['importance'],
             'o-', markersize=6, linewidth=2, label=feature)
ax2.set_xlabel('Age (years)', fontweight='bold')
ax2.set_ylabel('Importance', fontweight='bold')
ax2.set_title('B. Top Risk Factors Evolution', fontweight='bold', loc='left')
ax2.legend(fontsize=9)
ax2.grid(True, alpha=0.3)

# Panel 3: Cohort trajectories (simplified)
ax3 = fig.add_subplot(gs[1, 0])
for income in ['<$15k', '$50k-$100k', '>$200k']:
    traj_data = trajectories[trajectories['income_group'] == income].sort_values('age_numeric')
    if len(traj_data) > 0:
        ax3.plot(traj_data['age_numeric'], traj_data['diabetes_rate'] * 100,
                 'o-', markersize=6, linewidth=2, label=income)
ax3.set_xlabel('Age (years)', fontweight='bold')
ax3.set_ylabel('Diabetes Rate (%)', fontweight='bold')
ax3.set_title('C. Income-Based Trajectories', fontweight='bold', loc='left')
ax3.legend(fontsize=9)
ax3.grid(True, alpha=0.3)

# Panel 4: Transfer learning
ax4 = fig.add_subplot(gs[1, 1])
ax4.bar(range(len(transfer)), transfer['auc_score'],
        color=plt.cm.viridis(transfer['auc_score']), alpha=0.8)
ax4.set_xticks(range(len(transfer)))
ax4.set_xticklabels(transfer['transition'], rotation=45, ha='right', fontsize=8)
ax4.set_ylabel('AUC Score', fontweight='bold')
ax4.set_title('D. Cross-Age Prediction', fontweight='bold', loc='left')
ax4.axhline(y=0.7, color='red', linestyle='--', alpha=0.5)
ax4.grid(True, alpha=0.3, axis='y')
ax4.set_ylim(0, 1)

# Panel 5: Survival curves
ax5 = fig.add_subplot(gs[2, 0])
for sex in survival['sex'].unique():
    surv_sex = survival[survival['sex'] == sex].groupby('age')['survival_prob'].mean().reset_index()
    ax5.plot(surv_sex['age'], surv_sex['survival_prob'] * 100,
             'o-', markersize=6, linewidth=2, label=sex)
ax5.set_xlabel('Age (years)', fontweight='bold')
ax5.set_ylabel('Survival Probability (%)', fontweight='bold')
ax5.set_title('E. Diabetes-Free Survival', fontweight='bold', loc='left')
ax5.legend(fontsize=9)
ax5.grid(True, alpha=0.3)

# Panel 6: Summary statistics
ax6 = fig.add_subplot(gs[2, 1])
ax6.axis('off')

summary_text = f"""
FORECASTING SUMMARY

Total Observations: {len(pd.read_csv('LLCP2024_cleaned.csv', low_memory=False)):,}

Age Progression:
  • Current max prevalence: {prevalence['prevalence'].max()*100:.1f}% (Age 65+)
  • Forecasted age 80: {forecast.iloc[-1]['forecasted_prevalence']*100:.1f}%

Risk Factor Evolution:
  • Top factor across all ages: {importance_pivot.sum(axis=1).idxmax()}
  • Most age-dependent factor: {importance_pivot.std(axis=1).idxmax()}

Cohort Insights:
  • Highest risk trajectory: <$15k income group
  • Steepest increase: Ages 45-65

Transfer Learning:
  • Best cross-age prediction: AUC = {transfer['auc_score'].max():.3f}
  • Avg prediction accuracy: AUC = {transfer['auc_score'].mean():.3f}

Survival Analysis:
  • Age 30 diabetes-free: ~95%
  • Age 70 diabetes-free: ~{survival[survival['age']>70]['survival_prob'].mean()*100:.0f}%
"""

ax6.text(0.1, 0.95, summary_text, fontsize=10, verticalalignment='top',
         family='monospace', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))

fig.suptitle('Comprehensive Forecasting Dashboard: Age-Based Diabetes Risk Analysis',
             fontsize=16, fontweight='bold', y=0.995)

plt.savefig('viz_comprehensive_dashboard.png', bbox_inches='tight')
print("  ✓ Saved: viz_comprehensive_dashboard.png")
plt.close()

# ============================================================================
# SUMMARY
# ============================================================================

print("\n" + "="*80)
print("VISUALIZATION SUITE COMPLETE")
print("="*80)

print("\nGenerated Visualizations:")
print("  1. viz_age_progression_forecast.png")
print("  2. viz_feature_importance_evolution.png")
print("  3. viz_feature_importance_trends.png")
print("  4. viz_cohort_trajectories.png")
print("  5. viz_survival_curves.png")
print("  6. viz_transfer_learning.png")
print("  7. viz_timeseries_forecast.png")
print("  8. viz_comprehensive_dashboard.png")

print("\n" + "="*80)
