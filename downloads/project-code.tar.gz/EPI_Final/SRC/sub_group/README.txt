## The Methods 

We used 9 different forecasting approaches:

1. **Simple curves** - Fit smooth lines through age groups
2. **Machine learning** - Let computers find patterns in the data
3. **Time series methods** - Borrowed from stock market forecasting
4. **Ensemble** - Combine all methods for best results

Think of it like asking 9 different experts and averaging their predictions.

## Key Output Files

### For General Audience:
- **viz_comprehensive_dashboard.png** - One picture showing all main findings


### For Researchers:
- **10 CSV files** - Raw numbers for all analyses
- **9 PNG files** - Publication-ready figures
- **1 HTML dashboard** - Interactive exploration tool

## What You Can Do With This

### For Public Health Officials:
- Identify which age groups need prevention programs
- Target resources to high-risk populations
- Understand why income inequality matters for health

### For Healthcare Providers:
- Screen patients differently based on age
- Focus on modifiable risk factors (weight, healthcare access)
- Counsel patients about age-specific risks

### For Researchers:
- Build on our methods for other diseases
- Test interventions in age-specific groups
- Validate findings in other countries

## Limitations

1. **Cross-sectional data**: We measured everyone at one time point (2024), not following same people over years
2. **Self-reported diabetes**: People told us if they have diabetes; some may not know
3. **Missing data**: Many people didn't answer all questions
4. **U.S. only**: Results may not apply to other countries

## Quick Start

Want to run the analysis yourself?

```bash
cd forecasting_analysis
python run_all_forecasting.py
```

Wait 3-5 minutes, then open `viz_comprehensive_dashboard.png` to see results.

---

## Subgroup Analyses Explained

### What Are Subgroups?

We divided people into smaller groups to see if patterns differ:

**By Age** (6 groups):
- 18-24 years old
- 25-34 years old
- 35-44 years old
- 45-54 years old
- 55-64 years old
- 65+ years old

**By Income** (7 groups):
- Less than $15,000/year
- $15,000-$25,000/year
- $25,000-$35,000/year
- $35,000-$50,000/year
- $50,000-$75,000/year
- $75,000-$100,000/year
- $100,000-$200,000/year

### Why Subgroups Matter

**Example**: Overall diabetes rate is 15% in middle-aged adults. But if we look closer:
- Low-income middle-aged adults: 22% have diabetes
- High-income middle-aged adults: 9% have diabetes

The overall number (15%) hides a huge inequality!

### Main Subgroup Findings

#### 1. Age Groups Show Different Risk Factors

**Young Adults (18-24)**:
- Top risk factors: Income, food security, general health
- Bottom risk factors: BMI, race
- **Interpretation**: Social factors matter more than biology when you're young

**Middle-Aged (45-54)**:
- Top risk factors: BMI, healthcare access, general health
- **Interpretation**: Weight and seeing a doctor become critical

**Seniors (65+)**:
- Top risk factor: BMI (dominates everything else)
- Also important: Race, general health
- **Interpretation**: Biology takes over; weight is king

#### 2. Income Groups Show Widening Gaps

We tracked each income group from age 20 to age 70:

**Low-income trajectory**:
- Age 20: 2% diabetes
- Age 40: 12% diabetes
- Age 70: 31% diabetes

**High-income trajectory**:
- Age 20: 1% diabetes
- Age 40: 7% diabetes
- Age 70: 17% diabetes

**The gap grows**: From 1 percentage point at age 20 to 14 percentage points at age 70.

#### 3. Transfer Learning (Prediction Across Ages)

We tested: Can we predict diabetes in 50-year-olds using data from 40-year-olds?

**Results**:
- Best prediction: 40-year-olds → 50-year-olds (78% accuracy)
- Worst prediction: 20-year-olds → 30-year-olds (70% accuracy)
- Average: 75% accuracy across all age transitions

**Interpretation**: Risk factors are somewhat consistent as people age, but young adults are harder to predict.

### How Subgroup Analysis Works (Simple Explanation)

Imagine you want to know if height affects basketball ability:

**Wrong way**: Average everyone together
- Average height: 5'8"
- Average basketball skill: Medium
- Conclusion: Height doesn't matter much

**Right way**: Look at subgroups
- Under 5'5": Mostly low skill
- 5'5"-6'0": Mixed skill
- Over 6'0": Mostly high skill
- Conclusion: Height matters a lot!

Same idea with diabetes:

**Wrong way**: "Diabetes risk increases with age"
**Right way**: "Diabetes risk increases with age, BUT low-income people have 2× higher risk at every age, AND the gap gets worse over time"

### Key Subgroup Visualizations

1. **viz_cohort_trajectories.png**: Shows how each income group's risk changes with age
2. **viz_feature_importance_evolution.png**: Shows which factors matter at each age
3. **viz_transfer_learning.png**: Shows prediction accuracy across age groups
4. **viz_survival_curves.png**: Shows probability of staying diabetes-free by income

### Practical Use of Subgroup Results

**For a 25-year-old low-income person**:
- Current risk: 3% (low)
- Projected risk at age 50: 20% (high)
- Most important factors: Income, food security, healthcare access
- **Recommendation**: Policy interventions (living wage, SNAP, Medicaid expansion)

**For a 55-year-old high-income person**:
- Current risk: 14% (moderate)
- Projected risk at age 70: 17% (moderate)
- Most important factor: BMI
- **Recommendation**: Clinical interventions (weight loss programs, diabetes screening)

---

## Technical Terms Simplified

- **Prevalence**: Percentage of people with diabetes at one time
- **Incidence**: New cases per year (we don't have this)
- **Cross-sectional**: Snapshot at one time point (2024)
- **Longitudinal**: Following same people over many years (we don't have this)
- **SHAP values**: Method to measure which factors matter most
- **AUC**: Prediction accuracy score (0.5 = random guess, 1.0 = perfect)
- **Confidence interval**: Range of uncertainty around our prediction
- **Percentage point**: Absolute difference (20% → 25% = +5 pp, not +25%)

---

## Bottom Line

This project shows that:
1. Diabetes risk increases dramatically with age (16-fold increase)
2. What causes diabetes changes as you age (social factors → clinical factors)
3. Income inequality in health gets worse over time (21-fold amplification)
4. We can predict future risk well enough to target interventions (75% accuracy)

The main innovation: We combined traditional epidemiology with modern machine learning to get a more complete picture of how diabetes develops across the lifespan.

---

