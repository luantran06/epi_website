"""
Interactive HTML Dashboard for Forecasting Results

Creates an interactive HTML dashboard with:
- Dynamic plots using Plotly
- Tabbed interface for different analyses
- Summary statistics and insights
- Downloadable results

Author: Diabetes Risk Analysis Project
"""

import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px

print("="*80)
print("INTERACTIVE DASHBOARD GENERATOR")
print("="*80)

# ============================================================================
# LOAD ALL DATA
# ============================================================================

print("\nLoading forecast results...")

try:
    prevalence = pd.read_csv('forecast_age_prevalence.csv')
    forecast = pd.read_csv('forecast_future_prevalence.csv')
    importance = pd.read_csv('forecast_feature_importance_by_age.csv')
    trajectories = pd.read_csv('forecast_cohort_trajectories.csv')
    survival = pd.read_csv('forecast_survival_curves.csv')
    transfer = pd.read_csv('forecast_transfer_learning_results.csv')
    ensemble = pd.read_csv('forecast_advanced_ensemble.csv')
    model_comp = pd.read_csv('forecast_model_comparison.csv')

    print("✓ All data files loaded successfully")
except FileNotFoundError as e:
    print(f"✗ Error: {e}")
    print("Please run forecasting_pipeline.py first")
    exit(1)

# ============================================================================
# CREATE INTERACTIVE PLOTS
# ============================================================================

print("\nGenerating interactive visualizations...")

# Plot 1: Age Progression with Forecast
fig1 = go.Figure()

# Observed data
fig1.add_trace(go.Scatter(
    x=prevalence['age_numeric'],
    y=prevalence['prevalence'] * 100,
    mode='lines+markers',
    name='Observed Data',
    line=dict(color='#2E86AB', width=3),
    marker=dict(size=10, color='#2E86AB', line=dict(color='white', width=2))
))

# Forecasted data
fig1.add_trace(go.Scatter(
    x=forecast['age'],
    y=forecast['forecasted_prevalence'] * 100,
    mode='lines+markers',
    name='Polynomial Forecast',
    line=dict(color='#A23B72', width=3, dash='dash'),
    marker=dict(size=8, symbol='square', color='#A23B72')
))

# Ensemble forecast
fig1.add_trace(go.Scatter(
    x=ensemble['age'],
    y=ensemble['ensemble_forecast'] * 100,
    mode='lines+markers',
    name='Ensemble Forecast',
    line=dict(color='#E63946', width=3, dash='dot'),
    marker=dict(size=8, symbol='diamond', color='#E63946')
))

# Confidence interval
fig1.add_trace(go.Scatter(
    x=np.concatenate([ensemble['age'], ensemble['age'][::-1]]),
    y=np.concatenate([ensemble['upper_ci'] * 100, ensemble['lower_ci'][::-1] * 100]),
    fill='toself',
    fillcolor='rgba(230, 57, 70, 0.2)',
    line=dict(color='rgba(255,255,255,0)'),
    name='95% CI',
    showlegend=True
))

fig1.update_layout(
    title='Age Progression Forecasting: Diabetes Prevalence',
    xaxis_title='Age (years)',
    yaxis_title='Diabetes Prevalence (%)',
    hovermode='x unified',
    template='plotly_white',
    height=600,
    font=dict(size=12)
)

# Plot 2: Feature Importance Heatmap
importance_pivot = importance.pivot(index='feature', columns='age_group', values='importance')
age_order = ['18-24', '25-34', '35-44', '45-54', '55-64', '65+']
importance_pivot = importance_pivot[[col for col in age_order if col in importance_pivot.columns]]
importance_pivot['total'] = importance_pivot.sum(axis=1)
importance_pivot = importance_pivot.sort_values('total', ascending=False).drop('total', axis=1).head(15)

fig2 = go.Figure(data=go.Heatmap(
    z=importance_pivot.values,
    x=importance_pivot.columns,
    y=importance_pivot.index,
    colorscale='YlOrRd',
    text=importance_pivot.values,
    texttemplate='%{text:.3f}',
    textfont={"size": 10},
    colorbar=dict(title="Importance")
))

fig2.update_layout(
    title='Risk Factor Importance Evolution Across Age Groups',
    xaxis_title='Age Group',
    yaxis_title='Risk Factor',
    height=700,
    template='plotly_white',
    font=dict(size=11)
)

# Plot 3: Cohort Trajectories
fig3 = go.Figure()

income_colors = {
    '<$15k': '#D62828', '$15k-$25k': '#F77F00',
    '$25k-$35k': '#FCBF49', '$35k-$50k': '#EAE2B7',
    '$50k-$100k': '#06AED5', '$100k-$200k': '#0353A4',
    '>$200k': '#023E7D'
}

for income in trajectories['income_group'].unique():
    traj_data = trajectories[trajectories['income_group'] == income].sort_values('age_numeric')

    fig3.add_trace(go.Scatter(
        x=traj_data['age_numeric'],
        y=traj_data['diabetes_rate'] * 100,
        mode='lines+markers',
        name=income,
        line=dict(color=income_colors.get(income, '#000000'), width=3),
        marker=dict(size=8)
    ))

fig3.update_layout(
    title='Cohort Trajectory Forecasting by Income Level',
    xaxis_title='Age (years)',
    yaxis_title='Diabetes Prevalence (%)',
    hovermode='x unified',
    template='plotly_white',
    height=600,
    font=dict(size=12),
    legend=dict(orientation="v", yanchor="top", y=1, xanchor="right", x=1)
)

# Plot 4: Transfer Learning Performance
fig4 = go.Figure()

fig4.add_trace(go.Bar(
    x=transfer['source_age'] + ' → ' + transfer['target_age'],
    y=transfer['auc_score'],
    marker=dict(
        color=transfer['auc_score'],
        colorscale='Viridis',
        showscale=True,
        colorbar=dict(title="AUC Score")
    ),
    text=transfer['auc_score'].round(3),
    textposition='outside',
    textfont=dict(size=12, color='black')
))

fig4.add_hline(y=0.5, line_dash="dash", line_color="red",
               annotation_text="Random Guess", annotation_position="right")
fig4.add_hline(y=0.7, line_dash="dash", line_color="orange",
               annotation_text="Good Performance", annotation_position="right")

fig4.update_layout(
    title='Transfer Learning: Cross-Age Prediction Performance',
    xaxis_title='Age Transition',
    yaxis_title='AUC Score',
    template='plotly_white',
    height=600,
    font=dict(size=12),
    yaxis=dict(range=[0, 1])
)

# Plot 5: Model Comparison
fig5 = go.Figure()

fig5.add_trace(go.Bar(
    y=model_comp['Model'],
    x=model_comp['MAE'],
    orientation='h',
    marker=dict(
        color=['#2A9D8F', '#E76F51', '#F4A261', '#E63946'],
        line=dict(color='black', width=2)
    ),
    text=model_comp['MAE'].round(4),
    textposition='outside',
    textfont=dict(size=12, color='black')
))

fig5.update_layout(
    title='Forecasting Model Performance Comparison',
    xaxis_title='Mean Absolute Error (lower is better)',
    yaxis_title='Model',
    template='plotly_white',
    height=500,
    font=dict(size=12)
)

# Plot 6: Survival Curves
fig6 = go.Figure()

for sex in survival['sex'].unique():
    surv_sex = survival[survival['sex'] == sex].groupby('age')['survival_prob'].mean().reset_index()

    fig6.add_trace(go.Scatter(
        x=surv_sex['age'],
        y=surv_sex['survival_prob'] * 100,
        mode='lines+markers',
        name=sex,
        line=dict(width=3),
        marker=dict(size=8)
    ))

fig6.update_layout(
    title='Diabetes-Free Survival Probability by Sex',
    xaxis_title='Age (years)',
    yaxis_title='Survival Probability (%)',
    hovermode='x unified',
    template='plotly_white',
    height=600,
    font=dict(size=12),
    yaxis=dict(range=[0, 105])
)

# ============================================================================
# CREATE HTML DASHBOARD
# ============================================================================

print("\nGenerating HTML dashboard...")

html_template = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Diabetes Forecasting Dashboard</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        .header h1 {{
            margin: 0;
            font-size: 2.5em;
        }}
        .header p {{
            margin: 10px 0 0 0;
            font-size: 1.2em;
            opacity: 0.9;
        }}
        .tabs {{
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }}
        .tab {{
            padding: 15px 30px;
            background-color: white;
            border: none;
            cursor: pointer;
            border-radius: 8px;
            font-size: 1em;
            transition: all 0.3s;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .tab:hover {{
            background-color: #667eea;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }}
        .tab.active {{
            background-color: #667eea;
            color: white;
        }}
        .tab-content {{
            display: none;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .tab-content.active {{
            display: block;
            animation: fadeIn 0.5s;
        }}
        @keyframes fadeIn {{
            from {{ opacity: 0; }}
            to {{ opacity: 1; }}
        }}
        .plot-container {{
            margin: 20px 0;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}
        .stat-card {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        .stat-card h3 {{
            margin: 0 0 10px 0;
            font-size: 0.9em;
            opacity: 0.9;
        }}
        .stat-card p {{
            margin: 0;
            font-size: 2em;
            font-weight: bold;
        }}
        .insight-box {{
            background-color: #e3f2fd;
            border-left: 4px solid #2196f3;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
        }}
        .insight-box h3 {{
            margin-top: 0;
            color: #1976d2;
        }}
        .footer {{
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            color: #666;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔮 Diabetes Risk Forecasting Dashboard</h1>
        <p>Comprehensive Age-Based Analysis | Interactive Visualizations</p>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <h3>Total Observations</h3>
            <p>{len(pd.read_csv('../LLCP2024_cleaned.csv', low_memory=False)):,}</p>
        </div>
        <div class="stat-card">
            <h3>Age Groups Analyzed</h3>
            <p>6</p>
        </div>
        <div class="stat-card">
            <h3>Forecasting Models</h3>
            <p>7</p>
        </div>
        <div class="stat-card">
            <h3>Best Model AUC</h3>
            <p>{transfer['auc_score'].max():.3f}</p>
        </div>
    </div>

    <div class="tabs">
        <button class="tab active" onclick="showTab(0)">📈 Age Progression</button>
        <button class="tab" onclick="showTab(1)">🔥 Feature Evolution</button>
        <button class="tab" onclick="showTab(2)">👥 Cohort Trajectories</button>
        <button class="tab" onclick="showTab(3)">🎯 Transfer Learning</button>
        <button class="tab" onclick="showTab(4)">⚖️ Model Comparison</button>
        <button class="tab" onclick="showTab(5)">💊 Survival Curves</button>
    </div>

    <div class="tab-content active" id="tab0">
        <h2>Age Progression Forecasting</h2>
        <div class="insight-box">
            <h3>📊 Key Insights</h3>
            <ul>
                <li>Diabetes prevalence increases exponentially with age</li>
                <li>Current max prevalence: <strong>{prevalence['prevalence'].max()*100:.1f}%</strong> at age 65+</li>
                <li>Forecasted prevalence at age 80: <strong>{ensemble.iloc[1]['ensemble_forecast']*100:.1f}%</strong></li>
                <li>95% CI: [{ensemble.iloc[1]['lower_ci']*100:.1f}%, {ensemble.iloc[1]['upper_ci']*100:.1f}%]</li>
            </ul>
        </div>
        <div class="plot-container" id="plot1"></div>
    </div>

    <div class="tab-content" id="tab1">
        <h2>Risk Factor Importance Evolution</h2>
        <div class="insight-box">
            <h3>🔍 Key Insights</h3>
            <ul>
                <li>Top consistent factor: <strong>{importance.groupby('feature')['importance'].mean().idxmax()}</strong></li>
                <li>Most age-dependent: <strong>{importance.groupby('feature')['importance'].std().idxmax()}</strong></li>
                <li>15 key features tracked across 6 age groups</li>
                <li>Importance patterns reveal how risk profiles change with aging</li>
            </ul>
        </div>
        <div class="plot-container" id="plot2"></div>
    </div>

    <div class="tab-content" id="tab2">
        <h2>Cohort Trajectory Forecasting</h2>
        <div class="insight-box">
            <h3>💰 Key Insights</h3>
            <ul>
                <li>Clear income gradient in diabetes trajectories</li>
                <li>Lowest income group shows steepest increase with age</li>
                <li>Income disparities widen after age 45</li>
                <li>Trajectories forecast future cohort outcomes</li>
            </ul>
        </div>
        <div class="plot-container" id="plot3"></div>
    </div>

    <div class="tab-content" id="tab3">
        <h2>Transfer Learning Performance</h2>
        <div class="insight-box">
            <h3>🤖 Key Insights</h3>
            <ul>
                <li>Best transfer: <strong>{transfer.loc[transfer['auc_score'].idxmax(), 'source_age']} → {transfer.loc[transfer['auc_score'].idxmax(), 'target_age']}</strong> (AUC: {transfer['auc_score'].max():.3f})</li>
                <li>Average cross-age AUC: <strong>{transfer['auc_score'].mean():.3f}</strong></li>
                <li>Models trained on younger ages can predict older age risk</li>
                <li>Performance remains strong across age transitions</li>
            </ul>
        </div>
        <div class="plot-container" id="plot4"></div>
    </div>

    <div class="tab-content" id="tab4">
        <h2>Forecasting Model Comparison</h2>
        <div class="insight-box">
            <h3>⚖️ Key Insights</h3>
            <ul>
                <li>Best model: <strong>{model_comp.loc[model_comp['MAE'].idxmin(), 'Model']}</strong></li>
                <li>Lowest MAE: <strong>{model_comp['MAE'].min():.4f}</strong></li>
                <li>Ensemble approach combines strengths of multiple methods</li>
                <li>All models perform well, validating forecasts</li>
            </ul>
        </div>
        <div class="plot-container" id="plot5"></div>
    </div>

    <div class="tab-content" id="tab5">
        <h2>Survival Analysis</h2>
        <div class="insight-box">
            <h3>💊 Key Insights</h3>
            <ul>
                <li>Diabetes-free survival decreases with age</li>
                <li>Sex differences in survival trajectories</li>
                <li>Age 70 survival: ~{survival[survival['age']>70]['survival_prob'].mean()*100:.0f}%</li>
                <li>Useful for risk counseling and prevention planning</li>
            </ul>
        </div>
        <div class="plot-container" id="plot6"></div>
    </div>

    <div class="footer">
        <p>Generated by Diabetes Risk Forecasting Pipeline | BRFSS 2024 Data</p>
        <p>Interactive Dashboard | All visualizations are dynamic and zoomable</p>
    </div>

    <script>
        // Plot data
        var plot1Data = {fig1.to_json()};
        var plot2Data = {fig2.to_json()};
        var plot3Data = {fig3.to_json()};
        var plot4Data = {fig4.to_json()};
        var plot5Data = {fig5.to_json()};
        var plot6Data = {fig6.to_json()};

        // Render plots
        Plotly.newPlot('plot1', plot1Data.data, plot1Data.layout, {{responsive: true}});
        Plotly.newPlot('plot2', plot2Data.data, plot2Data.layout, {{responsive: true}});
        Plotly.newPlot('plot3', plot3Data.data, plot3Data.layout, {{responsive: true}});
        Plotly.newPlot('plot4', plot4Data.data, plot4Data.layout, {{responsive: true}});
        Plotly.newPlot('plot5', plot5Data.data, plot5Data.layout, {{responsive: true}});
        Plotly.newPlot('plot6', plot6Data.data, plot6Data.layout, {{responsive: true}});

        // Tab switching
        function showTab(index) {{
            var tabs = document.getElementsByClassName('tab');
            var contents = document.getElementsByClassName('tab-content');

            for (var i = 0; i < tabs.length; i++) {{
                tabs[i].classList.remove('active');
                contents[i].classList.remove('active');
            }}

            tabs[index].classList.add('active');
            contents[index].classList.add('active');
        }}
    </script>
</body>
</html>
"""

# Save HTML dashboard
with open('forecasting_dashboard.html', 'w') as f:
    f.write(html_template)

print("✓ Interactive dashboard generated: forecasting_dashboard.html")
print("\n" + "="*80)
print("DASHBOARD GENERATION COMPLETE")
print("="*80)
print("\nTo view the dashboard:")
print("  1. Open 'forecasting_dashboard.html' in your web browser")
print("  2. Navigate between tabs to explore different analyses")
print("  3. Hover over plots for detailed information")
print("  4. Use zoom and pan tools for closer inspection")
print("\n" + "="*80)
