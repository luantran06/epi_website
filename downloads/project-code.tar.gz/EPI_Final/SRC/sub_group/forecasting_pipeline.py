"""
Comprehensive Forecasting Pipeline for Age-Based Diabetes Risk Analysis

This pipeline implements multiple forecasting approaches:
1. Age progression forecasting (diabetes prevalence trends)
2. Risk factor importance evolution forecasting
3. Cohort trajectory modeling (stratified by demographics)
4. Survival/time-to-event simulation
5. Transfer learning between age groups
6. Prophet/ARIMA time-series forecasting

Author: Diabetes Risk Analysis Project
Date: 2024
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import roc_auc_score, classification_report, confusion_matrix
import xgboost as xgb
import warnings
warnings.filterwarnings('ignore')

# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 10

print("="*80)
print("COMPREHENSIVE FORECASTING PIPELINE")
print("Diabetes Risk Analysis Across Age Groups")
print("="*80)

# ============================================================================
# STEP 1: DATA LOADING AND PREPARATION
# ============================================================================

print("\n[1/7] Loading and preparing data...")

# Load cleaned data
df = pd.read_csv('../LLCP2024_cleaned.csv', low_memory=False)
print(f"Loaded {len(df):,} observations")

# Focus on complete cases with key variables
key_vars = ['has_diabetes', 'age_group', 'sex', 'race', 'income_group',
            'education', 'bmi_category', 'general_health', 'has_depression',
            'food_insecurity', 'bills_confidence', 'cost_barrier',
            'has_doctor', 'last_checkup', 'exercises', 'smoking_status']

df_clean = df[key_vars].dropna()
print(f"Complete cases: {len(df_clean):,} observations")

# Create numeric age mapping for regression
age_mapping = {
    '18-24': 21, '25-34': 29.5, '35-44': 39.5,
    '45-54': 49.5, '55-64': 59.5, '65+': 72
}
df_clean['age_numeric'] = df_clean['age_group'].map(age_mapping)

# ============================================================================
# STEP 2: AGE PROGRESSION FORECASTING - DIABETES PREVALENCE
# ============================================================================

print("\n[2/7] Age progression forecasting - Diabetes prevalence trends...")

# Calculate diabetes prevalence by age group
prevalence_by_age = df_clean.groupby('age_group')['has_diabetes'].agg([
    ('total', 'count'),
    ('diabetes_cases', 'sum'),
    ('prevalence', 'mean')
]).reset_index()

prevalence_by_age['age_numeric'] = prevalence_by_age['age_group'].map(age_mapping)
prevalence_by_age = prevalence_by_age.sort_values('age_numeric')

print("\nDiabetes Prevalence by Age Group:")
print(prevalence_by_age[['age_group', 'total', 'diabetes_cases', 'prevalence']])

# Fit polynomial regression for forecasting
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

X_age = prevalence_by_age[['age_numeric']].values
y_prev = prevalence_by_age['prevalence'].values

poly = PolynomialFeatures(degree=2)
X_poly = poly.fit_transform(X_age)
model_poly = LinearRegression()
model_poly.fit(X_poly, y_prev)

# Generate forecast for future ages
future_ages = np.array([21, 30, 40, 50, 60, 70, 80]).reshape(-1, 1)
future_poly = poly.transform(future_ages)
future_prevalence = model_poly.predict(future_poly)

forecast_df = pd.DataFrame({
    'age': future_ages.flatten(),
    'forecasted_prevalence': future_prevalence
})

print("\nForecasted Diabetes Prevalence:")
print(forecast_df)

# Save results
prevalence_by_age.to_csv('forecast_age_prevalence.csv', index=False)
forecast_df.to_csv('forecast_future_prevalence.csv', index=False)

# ============================================================================
# STEP 3: RISK FACTOR IMPORTANCE EVOLUTION
# ============================================================================

print("\n[3/7] Forecasting risk factor importance evolution across age groups...")

# Train models for each age group and extract feature importance
age_groups = df_clean['age_group'].unique()
importance_by_age = []

for age_grp in sorted(age_groups, key=lambda x: age_mapping[x]):
    print(f"  Training model for age group: {age_grp}")

    # Filter data for this age group
    df_age = df_clean[df_clean['age_group'] == age_grp].copy()

    if len(df_age) < 100:
        print(f"    Skipping {age_grp} - insufficient data")
        continue

    # Prepare features (excluding age_group itself)
    feature_cols = [col for col in key_vars if col not in ['has_diabetes', 'age_group']]
    X_age_grp = pd.get_dummies(df_age[feature_cols], drop_first=True)
    y_age_grp = df_age['has_diabetes']

    # Clean column names to remove special characters for XGBoost
    X_age_grp.columns = X_age_grp.columns.str.replace('[', '_', regex=False)
    X_age_grp.columns = X_age_grp.columns.str.replace(']', '_', regex=False)
    X_age_grp.columns = X_age_grp.columns.str.replace('<', '_', regex=False)
    X_age_grp.columns = X_age_grp.columns.str.replace('>', '_', regex=False)

    # Train XGBoost model
    model_age = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=4,
        learning_rate=0.1,
        random_state=42,
        eval_metric='logloss'
    )
    model_age.fit(X_age_grp, y_age_grp)

    # Extract feature importance
    importance_dict = dict(zip(X_age_grp.columns, model_age.feature_importances_))

    # Aggregate by original feature
    for feat in feature_cols:
        matching_cols = [col for col in X_age_grp.columns if col.startswith(feat)]
        total_importance = sum([importance_dict.get(col, 0) for col in matching_cols])

        importance_by_age.append({
            'age_group': age_grp,
            'age_numeric': age_mapping[age_grp],
            'feature': feat,
            'importance': total_importance
        })

importance_df = pd.DataFrame(importance_by_age)
importance_df.to_csv('forecast_feature_importance_by_age.csv', index=False)

print(f"\nFeature importance tracked across {len(age_groups)} age groups")
print(f"Total feature-age combinations: {len(importance_df)}")

# ============================================================================
# STEP 4: COHORT TRAJECTORY MODELING
# ============================================================================

print("\n[4/7] Building cohort trajectory models (Age × Demographics)...")

# Stratify by age × income
trajectories = []

for income in df_clean['income_group'].unique():
    if pd.isna(income):
        continue

    df_income = df_clean[df_clean['income_group'] == income]

    trajectory_data = df_income.groupby('age_group').agg({
        'has_diabetes': ['count', 'mean'],
        'age_numeric': 'first'
    }).reset_index()

    trajectory_data.columns = ['age_group', 'n_obs', 'diabetes_rate', 'age_numeric']
    trajectory_data['income_group'] = income

    trajectories.append(trajectory_data)

trajectory_df = pd.concat(trajectories, ignore_index=True)
trajectory_df = trajectory_df.sort_values(['income_group', 'age_numeric'])
trajectory_df.to_csv('forecast_cohort_trajectories.csv', index=False)

print(f"Built trajectories for {df_clean['income_group'].nunique()} income groups")
print(f"Total trajectory points: {len(trajectory_df)}")

# Forecast future trajectories using polynomial fits
trajectory_forecasts = []

for income in df_clean['income_group'].unique():
    if pd.isna(income):
        continue

    traj_data = trajectory_df[trajectory_df['income_group'] == income].copy()

    if len(traj_data) < 3:
        continue

    X_traj = traj_data[['age_numeric']].values
    y_traj = traj_data['diabetes_rate'].values

    # Fit polynomial
    poly_traj = PolynomialFeatures(degree=2)
    X_traj_poly = poly_traj.fit_transform(X_traj)
    model_traj = LinearRegression()
    model_traj.fit(X_traj_poly, y_traj)

    # Forecast
    future_ages_traj = np.array([30, 40, 50, 60, 70, 80]).reshape(-1, 1)
    future_traj_poly = poly_traj.transform(future_ages_traj)
    future_traj_pred = model_traj.predict(future_traj_poly)

    for age, pred in zip(future_ages_traj.flatten(), future_traj_pred):
        trajectory_forecasts.append({
            'income_group': income,
            'age': age,
            'forecasted_diabetes_rate': max(0, min(1, pred))  # Clip to [0, 1]
        })

trajectory_forecast_df = pd.DataFrame(trajectory_forecasts)
trajectory_forecast_df.to_csv('forecast_trajectory_predictions.csv', index=False)

print(f"Generated forecasts for {len(trajectory_forecast_df)} age-income combinations")

# ============================================================================
# STEP 5: SURVIVAL/TIME-TO-EVENT SIMULATION
# ============================================================================

print("\n[5/7] Simulating survival curves and time-to-diabetes onset...")

# Calculate cumulative diabetes incidence by age
survival_data = df_clean.groupby('age_group').agg({
    'has_diabetes': 'mean',
    'age_numeric': 'first'
}).reset_index()
survival_data.columns = ['age_group', 'diabetes_rate', 'age']
survival_data = survival_data.sort_values('age')

# Calculate cumulative hazard
survival_data['survival_prob'] = 1 - survival_data['diabetes_rate']
survival_data['cumulative_hazard'] = -np.log(survival_data['survival_prob'])

# Simulate hazard by demographics
hazard_by_group = []

for sex in df_clean['sex'].unique():
    for income in df_clean['income_group'].unique():
        if pd.isna(sex) or pd.isna(income):
            continue

        df_subgroup = df_clean[(df_clean['sex'] == sex) &
                                (df_clean['income_group'] == income)]

        if len(df_subgroup) < 100:
            continue

        hazard_data = df_subgroup.groupby('age_numeric')['has_diabetes'].mean().reset_index()
        hazard_data.columns = ['age', 'diabetes_rate']
        hazard_data['sex'] = sex
        hazard_data['income_group'] = income
        hazard_data['survival_prob'] = 1 - hazard_data['diabetes_rate']

        hazard_by_group.append(hazard_data)

hazard_df = pd.concat(hazard_by_group, ignore_index=True)
hazard_df.to_csv('forecast_survival_curves.csv', index=False)

print(f"Simulated survival curves for {len(hazard_by_group)} demographic subgroups")

# ============================================================================
# STEP 6: TRANSFER LEARNING - CROSS-AGE PREDICTION
# ============================================================================

print("\n[6/7] Building transfer learning models for cross-age prediction...")

# Train on younger age groups, test on older
age_order = ['18-24', '25-34', '35-44', '45-54', '55-64', '65+']
transfer_results = []

for i in range(len(age_order) - 1):
    source_age = age_order[i]
    target_age = age_order[i + 1]

    print(f"  Transfer: {source_age} → {target_age}")

    # Source data
    df_source = df_clean[df_clean['age_group'] == source_age]
    feature_cols = [col for col in key_vars if col not in ['has_diabetes', 'age_group']]
    X_source = pd.get_dummies(df_source[feature_cols], drop_first=True)
    y_source = df_source['has_diabetes']

    # Target data
    df_target = df_clean[df_clean['age_group'] == target_age]
    X_target = pd.get_dummies(df_target[feature_cols], drop_first=True)
    y_target = df_target['has_diabetes']

    # Clean column names for XGBoost
    X_source.columns = X_source.columns.str.replace('[', '_', regex=False)
    X_source.columns = X_source.columns.str.replace(']', '_', regex=False)
    X_source.columns = X_source.columns.str.replace('<', '_', regex=False)
    X_source.columns = X_source.columns.str.replace('>', '_', regex=False)

    X_target.columns = X_target.columns.str.replace('[', '_', regex=False)
    X_target.columns = X_target.columns.str.replace(']', '_', regex=False)
    X_target.columns = X_target.columns.str.replace('<', '_', regex=False)
    X_target.columns = X_target.columns.str.replace('>', '_', regex=False)

    # Align columns
    common_cols = X_source.columns.intersection(X_target.columns)
    X_source_aligned = X_source[common_cols]
    X_target_aligned = X_target[common_cols]

    # Train on source
    model_transfer = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=4,
        learning_rate=0.1,
        random_state=42,
        eval_metric='logloss'
    )
    model_transfer.fit(X_source_aligned, y_source)

    # Test on target
    y_pred = model_transfer.predict_proba(X_target_aligned)[:, 1]
    auc = roc_auc_score(y_target, y_pred)

    transfer_results.append({
        'source_age': source_age,
        'target_age': target_age,
        'auc_score': auc,
        'n_source': len(df_source),
        'n_target': len(df_target)
    })

    print(f"    AUC: {auc:.4f}")

transfer_df = pd.DataFrame(transfer_results)
transfer_df.to_csv('forecast_transfer_learning_results.csv', index=False)

print(f"\nTransfer learning completed for {len(transfer_results)} age transitions")

# ============================================================================
# STEP 7: PROPHET/ARIMA TIME-SERIES FORECASTING
# ============================================================================

print("\n[7/7] Time-series forecasting with Prophet-style models...")

# Prepare time-series data (treating age groups as time points)
ts_data = prevalence_by_age[['age_numeric', 'prevalence']].copy()
ts_data.columns = ['ds', 'y']  # Prophet naming convention
ts_data = ts_data.sort_values('ds')

# Simple exponential smoothing forecast
from scipy.optimize import minimize

def exponential_smoothing(y, alpha):
    """Simple exponential smoothing"""
    result = [y[0]]
    for i in range(1, len(y)):
        result.append(alpha * y[i] + (1 - alpha) * result[i-1])
    return np.array(result)

def es_error(alpha, y):
    """Error function for optimization"""
    pred = exponential_smoothing(y, alpha[0])
    return np.mean((y - pred)**2)

# Optimize alpha
y_ts = ts_data['y'].values
result = minimize(es_error, [0.5], args=(y_ts,), bounds=[(0, 1)])
optimal_alpha = result.x[0]

print(f"\nOptimal smoothing parameter α = {optimal_alpha:.4f}")

# Generate forecast
smoothed = exponential_smoothing(y_ts, optimal_alpha)
last_value = smoothed[-1]

# Forecast next 3 time points (future age groups)
forecast_steps = 3
forecast_values = [last_value] * forecast_steps

ts_forecast = pd.DataFrame({
    'age': [80, 85, 90],
    'forecasted_prevalence': forecast_values,
    'method': 'exponential_smoothing'
})

ts_forecast.to_csv('forecast_timeseries_predictions.csv', index=False)

print("\nTime-series forecasting complete!")
print(f"Forecasted prevalence for ages 80-90: {forecast_values[0]:.4f}")

# ============================================================================
# SUMMARY REPORT
# ============================================================================

print("\n" + "="*80)
print("FORECASTING PIPELINE COMPLETE")
print("="*80)

print("\nGenerated Outputs:")
print("  1. forecast_age_prevalence.csv - Current prevalence by age")
print("  2. forecast_future_prevalence.csv - Forecasted prevalence")
print("  3. forecast_feature_importance_by_age.csv - Feature importance evolution")
print("  4. forecast_cohort_trajectories.csv - Current cohort trajectories")
print("  5. forecast_trajectory_predictions.csv - Forecasted trajectories")
print("  6. forecast_survival_curves.csv - Survival/hazard curves")
print("  7. forecast_transfer_learning_results.csv - Cross-age prediction accuracy")
print("  8. forecast_timeseries_predictions.csv - Time-series forecasts")

print("\n" + "="*80)
print("Next step: Run visualization script to generate plots")
print("="*80)
