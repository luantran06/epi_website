import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load subgroup CSV
df = pd.read_csv("subgroup_top3_features.csv")

import ast
df["top_3_features"] = df["top_3_features"].apply(ast.literal_eval)

# Clean names
def clean_name(f):
    return (f.replace("cat__", "")
             .replace("num__", "")
             .replace("_", " ")
             .replace("last checkup Within past year", "recent checkup")
             .replace("general health Very good", "health very good")
             .replace("general health Excellent", "health excellent")
             .strip())

df["top_3_features_clean"] = df["top_3_features"].apply(lambda lst: [clean_name(x) for x in lst])
df["rank1_feature"] = df["top_3_features_clean"].apply(lambda x: x[0])

# Orders
age_order = ["18-24","25-34","35-44","45-54","55-64","65+"]
income_order = ["<$15k","$15k-$25k","$25k-$35k","$35k-$50k","$50k-$100k","$100k-$200k",">$200k"]

# Create pivot table of feature names
pivot = df.pivot(index="age_group", columns="income_group", values="rank1_feature")
pivot = pivot.reindex(index=age_order, columns=[x for x in income_order if x in pivot.columns])

# Map feature names → numeric codes
unique_features = sorted(set(pivot.values.ravel()))  # list of unique strings

feature_to_num = {feat: i+1 for i, feat in enumerate(unique_features)}
num_to_feature = {i+1: feat for feat, i in feature_to_num.items()}

pivot_numeric = pivot.replace(feature_to_num)

# Plot numeric heatmap but annotate with real names
plt.figure(figsize=(14, 8))

ax = sns.heatmap(pivot_numeric, annot=pivot, fmt="", cmap="YlGnBu",
                 linewidths=0.3, cbar=False)

plt.title("Most Important Feature (Rank #1) by Age × Income Group", fontsize=16)
plt.xlabel("Income Group")
plt.ylabel("Age Group")
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

all_features = []
for lst in df["top_3_features_clean"]:
    all_features.extend(lst)

freq = pd.Series(all_features).value_counts()

plt.figure(figsize=(10, 6))
sns.barplot(x=freq.values, y=freq.index, color="steelblue")
plt.title("Frequency of Features Appearing in Top-3 (All Subgroups)", fontsize=16)
plt.xlabel("Count")
plt.ylabel("Feature")
plt.tight_layout()
plt.savefig("subgroup_top3_frequency.png", dpi=300)
plt.show()

print("\nPlots saved:")
print(" → subgroup_rank1_heatmap.png")
print(" → subgroup_top3_frequency.png")