import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score
import xgboost as xgb
import shap
import matplotlib.pyplot as plt
import seaborn as sns

# ================================
# 1. Load data
# ================================
df = pd.read_csv("LLCP2024_cleaned.csv", low_memory=False)

df = df[df["has_diabetes"].notna()].copy()
y = df["has_diabetes"].astype(int)

# ================================
# 2. Define usable features
# ================================
features = [
    "sex","age_group","race",
    "income_group","education",
    "food_insecurity","bills_confidence","lacks_transport",
    "received_snap","employed_past_year",
    "exercises","smoking_status",

    "bmi_actual",         # numeric
    "bmi_category",

    "general_health","has_depression",
    "mental_health_days_cat","loneliness",
    "life_satisfaction","emotional_support",
    "has_doctor","has_insurance","last_checkup"
]

X = df[features]

# ================================
# 3. Correct preprocessing
# ================================
num_cols = ["bmi_actual"]
cat_cols = [c for c in features if c not in num_cols]

preprocessor = ColumnTransformer(transformers=[
    ("num", SimpleImputer(strategy="median"), num_cols),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols)
])


# ================================
# 4. Train-test split
# ================================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# ================================
# 5. Models
# ================================

# ---- LASSO logistic regression ----
logreg = Pipeline(steps=[
    ("prep", preprocessor),
    ("model", LogisticRegression(
        penalty="l1", solver="saga", max_iter=5000, C=0.5
    ))
])

logreg.fit(X_train, y_train)
print("LASSO finished.")
log_pred = logreg.predict_proba(X_test)[:,1]

# ---- Random Forest ----
rf = Pipeline(steps=[
    ("prep", preprocessor),
    ("model", RandomForestClassifier(
        n_estimators=300, max_depth=10, random_state=42
    ))
])

rf.fit(X_train, y_train)
print("RF finished.")
rf_pred = rf.predict_proba(X_test)[:,1]

# ---- XGBoost ----
prep_only = preprocessor.fit_transform(X_train)
prep_test = preprocessor.transform(X_test)

xgb_model = xgb.XGBClassifier(
    n_estimators=300, max_depth=4, learning_rate=0.05,
    subsample=0.8, colsample_bytree=0.8, eval_metric="logloss"
)

xgb_model.fit(prep_only, y_train)
print("XGB finished.")
xgb_pred = xgb_model.predict_proba(prep_test)[:,1]

# ================================
# 6. Performance comparison
# ================================

print("log_pred exists:", 'log_pred' in locals())
print("rf_pred exists:", 'rf_pred' in locals())
print("xgb_pred exists:", 'xgb_pred' in locals())


print("\n=== Model Performance ===")
print(f"LASSO Logistic Regression AUC: {roc_auc_score(y_test, log_pred):.3f}")
print(f"Random Forest AUC: {roc_auc_score(y_test, rf_pred):.3f}")
print(f"XGBoost AUC: {roc_auc_score(y_test, xgb_pred):.3f}")

# ================================
# 7. SHAP for XGBoost
# ================================
print("\nComputing SHAP values...")
explainer = shap.TreeExplainer(xgb_model)
shap_values = explainer(prep_test)

shap.summary_plot(shap_values, feature_names=preprocessor.get_feature_names_out())

# ================================
# 8. Subgroup SHAP (age × income)
# ================================
# ================================
# 8. Subgroup SHAP (age × income)
# ================================
df_test = X_test.copy()
df_test["y_true"] = y_test.values
df_test["y_pred"] = xgb_pred

# Add SHAP values per feature
shap_df = pd.DataFrame(
    shap_values.values,
    columns=preprocessor.get_feature_names_out()
)

shap_df["age_group"] = df_test["age_group"].values
shap_df["income_group"] = df_test["income_group"].values

# Drop missing
shap_df = shap_df.dropna(subset=["age_group", "income_group"])

# FIXED income categories (must match your cleaned dataset)
income_order = [
    '<$15k',
    '$15k-$25k',
    '$25k-$35k',
    '$35k-$50k',
    '$50k-$100k',
    '$100k-$200k',
    '>$200k'
]

valid_income_groups = [g for g in income_order if g in shap_df["income_group"].unique()]

results = []

for age in sorted(shap_df["age_group"].unique()):
    for inc in valid_income_groups:

        subset = shap_df[(shap_df["age_group"] == age) &
                         (shap_df["income_group"] == inc)]

        if len(subset) < 30:
            continue

        mean_abs = subset.drop(columns=["age_group", "income_group"]).abs().mean()
        top3 = mean_abs.sort_values(ascending=False).head(3)

        results.append({
            "age_group": age,
            "income_group": inc,
            "top_3_features": list(top3.index),
            "scores": list(top3.values)
        })

results_df = pd.DataFrame(results)
results_df.to_csv("subgroup_top3_features.csv", index=False)

print("\nSaved subgroup-specific top feature list → subgroup_top3_features.csv")
print(results_df.head())
