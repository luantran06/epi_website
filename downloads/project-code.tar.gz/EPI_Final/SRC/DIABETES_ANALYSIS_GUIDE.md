# BRFSS 2024 Diabetes Analysis - Column Guide

## Dataset Overview
- **Total Columns**: 301
- **Total Rows**: 457,671
- **Source**: BRFSS (Behavioral Risk Factor Surveillance System) 2024

---

## Primary Outcome Variable

**DIABETE4** - Diabetes diagnosis status
- `1` = Yes (diabetes)
- `2` = Yes, but only during pregnancy (gestational)
- `3` = No
- `4` = No, pre-diabetes or borderline
- `7` = Don't know/Not sure
- `9` = Refused

---

## Traditional Risk Factors (Well-Studied)

### 1. Anthropometric Measures
- **_BMI5** - Body Mass Index (continuous)
- **_BMI5CAT** - BMI category (underweight, normal, overweight, obese)
- **_RFBMI5** - Overweight or obese indicator
- **WEIGHT2** - Weight in pounds
- **HEIGHT3** - Height in inches

### 2. Demographics
- **_AGE_G** - Age groups (6 categories)
- **_AGEG5YR** - Age in 5-year intervals (14 categories)
- **_SEX** - Gender (1=Male, 2=Female)
- **_RACE** - Race/ethnicity (9 categories)
- **_EDUCAG** - Education level (4 categories)
- **_INCOMG1** - Income groups (8 categories)
- **MARITAL** - Marital status

### 3. Lifestyle - Physical Activity
- **EXERANY2** - Exercise in past 30 days (Yes/No)
- **_TOTINDA** - Physical activity indicator
- **DIFFWALK** - Difficulty walking/climbing stairs

### 4. Lifestyle - Nutrition
- **SSBSUGR2** - Sugar-sweetened beverage consumption (times per day/week/month)
- **SSBFRUT3** - 100% fruit juice consumption

### 5. Known Comorbidities
- **CVDINFR4** - Ever had heart attack
- **CVDCRHD4** - Ever had coronary heart disease
- **CVDSTRK3** - Ever had stroke
- **CHCKDNY2** - Ever told you have kidney disease
- **HAVARTH4** - Arthritis
- **CHCCOPD3** - COPD
- **ASTHMA3** - Asthma

---

## Underexplored/Unseen Risk Factors

### 1. Mental Health & Psychological Factors ⭐ HIGH PRIORITY

**Why important**: Bidirectional relationship between mental health and diabetes
- Chronic stress and depression affect glucose metabolism
- Diabetes diagnosis increases depression risk
- Mental health affects self-care behaviors

**Variables**:
- **ADDEPEV3** - Ever told you have depression
- **MENTHLTH** - Number of days mental health not good (past 30 days)
- **LSATISFY** - Life satisfaction (Very satisfied → Very dissatisfied)
- **SDLONELY** - How often feel lonely (Always → Never)
- **CDWORRY** - Confusion or memory loss
- **EMTSUPRT** - How often get emotional support needed

### 2. Social Determinants of Health (SDOH) ⭐ HIGH PRIORITY

**Why important**: Growing evidence that social/economic factors are as important as clinical factors
- Food insecurity linked to poor glycemic control
- Financial stress leads to medication non-adherence
- Housing instability disrupts care continuity

**Variables**:
- **FOODSTMP** - Received food stamps/SNAP in past 12 months
- **SDHFOOD1** - How often worried food would run out (Always → Never)
- **SDHBILLS** - How often worried couldn't pay bills (Always → Never)
- **SDHUTILS** - Difficulty paying for utilities
- **SDHTRNSP** - Lack of reliable transportation (Yes/No)
- **SDHEMPLY** - Employment in past 12 months
- **RENTHOM1** - Own or rent home
- **_INCOMG1** - Income level

### 3. Healthcare Access Barriers ⭐ MEDIUM-HIGH PRIORITY

**Why important**: Access affects early detection and disease management
- Cost barriers delay diagnosis
- Lack of regular doctor affects monitoring
- Preventive care access predicts better outcomes

**Variables**:
- **MEDCOST1** - Could not see doctor due to cost (past 12 months)
- **PERSDOC3** - Have personal doctor or healthcare provider
- **CHECKUP1** - Time since last routine checkup
- **PRIMINS2** - Primary health insurance type
- **_HLTHPL2** - Have any health plan coverage
- **_HCVU654** - Have healthcare coverage (ages 18-64)

### 4. Functional Limitations & Disability ⭐ MEDIUM PRIORITY

**Why important**: Bidirectional relationship (both cause and effect)
- Physical limitations may precede diabetes
- Diabetes complications cause disabilities
- Disabilities affect ability to exercise and self-care

**Variables**:
- **DEAF** - Serious difficulty hearing
- **BLIND** - Serious difficulty seeing
- **DECIDE** - Difficulty concentrating/remembering/deciding
- **DIFFWALK** - Difficulty walking/climbing stairs
- **DIFFDRES** - Difficulty dressing/bathing
- **DIFFALON** - Difficulty doing errands alone

### 5. Social Isolation & Support Networks ⭐ MEDIUM PRIORITY

**Why important**: Social connections affect health behaviors and stress
- Social isolation linked to poor medication adherence
- Emotional support buffers stress effects
- Marital status affects lifestyle patterns

**Variables**:
- **EMTSUPRT** - Emotional support availability
- **SDLONELY** - Frequency of loneliness
- **MARITAL** - Marital status
- **LSATISFY** - Overall life satisfaction

### 6. Substance Use Patterns

**Why important**: May indicate stress coping mechanisms
- Smoking increases diabetes risk
- Alcohol affects glucose metabolism
- Patterns may cluster with other risk behaviors

**Variables**:
- **SMOKE100** - Smoked at least 100 cigarettes
- **SMOKDAY2** - Current smoking frequency
- **_SMOKER3** - Computed smoking status
- **ALCDAY4** - Alcohol consumption frequency
- **AVEDRNK4** - Average drinks per day
- **DRNK3GE5** - Binge drinking episodes
- **_RFBING6** - Binge drinking indicator

### 7. General Health Status

**Variables**:
- **GENHLTH** - General health (Excellent → Poor)
- **PHYSHLTH** - Physical health not good (days in past 30)
- **POORHLTH** - Poor physical or mental health kept you from usual activities
- **_RFHLTH** - Fair or poor health

### 8. Caregiving Burden (Novel Factor) ⭐ EMERGING

**Why important**: Caregiver stress may affect diabetes risk
- Caregivers often neglect own health
- Chronic stress from caregiving affects metabolism
- Time constraints limit self-care

**Variables**:
- **CAREGIV1** - Provide care to family/friend with health problem
- **CRGVHRS2** - Hours per week providing care
- **CRGVREL5** - Relationship to care recipient
- **CRGVPRB4** - Primary health problem of recipient

### 9. Neighborhood Environment (Novel Factor) ⭐ EMERGING

**Why important**: Environmental factors affect physical activity
- Unsafe neighborhoods reduce outdoor activity
- May be proxy for stress/violence exposure

**Variables**:
- **HOWSAFE1** - How safe from crime is neighborhood

### 10. Preventive Care Engagement

**Why important**: Indicator of health-consciousness and access
- Dental disease linked to diabetes
- Preventive care use predicts better chronic disease management

**Variables**:
- **FLUSHOT7** - Received flu vaccine (past 12 months)
- **PNEUVAC4** - Ever received pneumonia vaccine
- **LASTDEN4** - Time since last dental visit

### 11. Adverse Childhood Experiences (ACEs) ⭐ HIGHLY NOVEL

**Why important**: Growing evidence linking childhood trauma to adult chronic disease
- ACEs affect stress response systems
- Associated with health risk behaviors
- May have intergenerational effects

**Variables**:
- **ACEDEPRS** - Live with depressed/mentally ill person (childhood)
- **ACEDRINK** - Live with problem drinker/alcoholic (childhood)
- **ACEDRUGS** - Live with illegal drug user (childhood)
- **ACEPRISN** - Live with person who went to prison (childhood)
- **ACEDIVRC** - Parents separated/divorced (childhood)
- **ACEPUNCH** - Parents/adults slapped/hit/kicked/punched each other
- **ACEHURT1** - Parent/adult hit/beat/kicked/physically hurt you
- **ACESWEAR** - Parent/adult swore/insulted/put you down
- **ACETOUCH** - Adult touched you sexually
- **ACETTHEM** - Adult made you touch them sexually
- **ACEHVSEX** - Forced to have sex

---

## Suggested Research Questions

### 1. Social Determinants Focus
**Question**: How do social determinants of health (food insecurity, housing instability, financial stress) predict diabetes risk beyond traditional clinical factors?

**Key Variables**: SDHFOOD1, SDHBILLS, SDHTRNSP, FOODSTMP, RENTHOM1, _INCOMG1
**Why Novel**: Most diabetes research focuses on clinical/behavioral factors; SDOH increasingly recognized as fundamental causes

### 2. Mental Health Pathway
**Question**: What is the bidirectional relationship between depression, loneliness, and diabetes incidence/management?

**Key Variables**: ADDEPEV3, SDLONELY, MENTHLTH, LSATISFY, EMTSUPRT
**Why Novel**: Mental health often treated as consequence rather than contributor to diabetes

### 3. Healthcare Access Mediation
**Question**: Do healthcare access barriers mediate the relationship between socioeconomic status and diabetes outcomes?

**Key Variables**: MEDCOST1, PERSDOC3, _HLTHPL2, _INCOMG1, _EDUCAG
**Why Novel**: Tests pathway mechanisms, not just associations

### 4. Functional Disability Interactions
**Question**: How do functional disabilities interact with diabetes risk - are they cause, effect, or both?

**Key Variables**: DIFFWALK, DECIDE, BLIND, DEAF, DIFFDRES
**Why Novel**: Longitudinal perspective needed; cross-sectional can identify associations

### 5. Social Support Buffering
**Question**: Does emotional support and social connectedness buffer diabetes risk in socioeconomically disadvantaged populations?

**Key Variables**: EMTSUPRT, SDLONELY, MARITAL × SDHFOOD1, SDHBILLS (interaction terms)
**Why Novel**: Tests protective factors, not just risk factors

### 6. ACEs and Current Stress Interaction
**Question**: Are there interaction effects between adverse childhood experiences and current social stressors on diabetes risk?

**Key Variables**: ACE variables × current SDOH variables
**Why Novel**: Examines life-course perspective on diabetes risk

### 7. Caregiver Burden
**Question**: Does caregiving burden increase diabetes risk, and is this mediated by stress and self-care neglect?

**Key Variables**: CAREGIV1, CRGVHRS2, MENTHLTH, CHECKUP1, EXERANY2
**Why Novel**: Understudied population; potential intervention target

---

## Analysis Recommendations

### Priority Tiers for Analysis

**TIER 1 - Must Include (Core Model)**:
- DIABETE4 (outcome)
- _BMI5CAT, _AGE_G, _SEX, _RACE (traditional risk factors)
- EXERANY2, GENHLTH (lifestyle/health)

**TIER 2 - High Impact Novel Factors**:
- ADDEPEV3, MENTHLTH, SDLONELY (mental health)
- SDHFOOD1, SDHBILLS, FOODSTMP (SDOH)
- MEDCOST1, PERSDOC3 (access)

**TIER 3 - Emerging Factors**:
- EMTSUPRT, LSATISFY (social support)
- DIFFWALK, DECIDE (functional status)
- CAREGIV1 (caregiving)

**TIER 4 - Highly Novel (if data available)**:
- ACE variables (childhood trauma)
- HOWSAFE1 (neighborhood)
- LASTDEN4 (preventive care engagement)

### Statistical Approaches

1. **Descriptive Analysis**: Prevalence of diabetes by key variables
2. **Multivariable Logistic Regression**: Adjusted associations
3. **Mediation Analysis**: Test pathways (e.g., SDOH → access → diabetes)
4. **Interaction Testing**: Effect modification (e.g., social support × SDOH)
5. **Machine Learning**: Random forests/XGBoost for variable importance
6. **Stratified Analysis**: By age, race, income to identify vulnerable groups

### Missing Data Considerations

Note that some variables have substantial missing data:
- ACE variables (may be asked only to subset)
- Some SDOH variables (not asked to all respondents)
- Diabetes management variables (asked only to diabetics)

Use appropriate missing data methods (complete case, multiple imputation, or indicate missingness as category for MNAR scenarios).

---

## Next Steps

1. **Data Cleaning**: Handle missing data, create derived variables
2. **Exploratory Analysis**: Distribution of key variables, correlation matrix
3. **Variable Selection**: Based on research question and collinearity
4. **Model Building**: Start simple, add complexity
5. **Validation**: Consider train/test split or cross-validation
6. **Interpretation**: Focus on modifiable factors for intervention

---

**Created**: 2025-11-01
**Dataset**: LLCP2024.csv (BRFSS 2024)
**Total Variables Available**: 301
