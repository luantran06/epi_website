"""
1. Classical filter-based selection (Chi-square)
2. Model-based selection (XGBoost + SHAP)
3. Side-by-side comparison plot

Input:
  - LLCP2024_cleaned.csv  (from preprocessing)

Output:
  - feature_importance_classical.csv
  - feature_importance_model.csv
  - feature_importance_model_grouped.csv
  - shap_summary_grouped.png
  - comparison_scatter.png
"""

import pandas as pd
import numpy as np
import xgboost as xgb
import shap
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from scipy.stats import chi2_contingency, f_oneway

# Load the data
print("Loading and preparing the data...")
df = pd.read_csv("LLCP2024_cleaned.csv", low_memory=False)
df = df.dropna(subset=["has_diabetes"])  # ensure target present
y = df["has_diabetes"].astype(int)

# Define predictors
feature_cols = [
    'sex','age_group','race','income_group','education',
    'bmi_actual','bmi_category', 'general_health','has_depression','mental_health_days_cat',
    'loneliness','life_satisfaction','emotional_support',
    'food_insecurity','bills_confidence','lacks_transport',
    'received_snap','employed_past_year','cost_barrier',
    'has_doctor','has_insurance','last_checkup',
    'exercises','smoking_status'
] # removed bmi_category to avoid redundancy

X = df[feature_cols]
num_cols = ['bmi_actual']
cat_cols = [c for c in feature_cols if c not in num_cols]


# 1. Classical Feature Selection (Chi-square)
print("Running Chi-square feature selection...\n")
results = []

# Chi-square for categorical predictors
for col in cat_cols:
    subset = df[[col, "has_diabetes"]].dropna()
    if subset[col].nunique() < 2:
        continue
    contingency = pd.crosstab(subset[col], subset["has_diabetes"])
    chi2, p, dof, _ = chi2_contingency(contingency)
    results.append({
        "variable": col,
        "test_type": "chi-square",
        "statistic": chi2,
        "p_value": p,
        "degrees_of_freedom": dof,
        "n_categories": subset[col].nunique()
    })

# Save results
classical_df = pd.DataFrame(results).sort_values("p_value", ascending=True).reset_index(drop=True)
classical_df["p_value_sci"] = classical_df["p_value"].apply(lambda x: f"{x:.1e}")
# Compute -log10(p) for visualization and comparison
classical_df["p_clipped"] = np.clip(classical_df["p_value"], 1e-300, 1.0)
classical_df["-log10(p)"] = -np.log10(classical_df["p_clipped"])

classical_df.to_csv("feature_importance_classical.csv", index=False)
print("Saved classical feature scores -> feature_importance_classical.csv")

# 2. Model-based Feature Selection (XGBoost)
print("\nRunning model-based feature selection (XGBoost + SHAP)...")

# Preprocess (impute + one-hot encode categorical)
cat_cols.remove('bmi_category')
preprocess = ColumnTransformer([
    ('num', SimpleImputer(strategy='median'), num_cols),
    ('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols)
])
X_encoded = preprocess.fit_transform(X)
feature_names = preprocess.get_feature_names_out()

X_train, X_test, y_train, y_test = train_test_split(
    X_encoded, y, test_size=0.2, stratify=y, random_state=42
)

# Train model
xgb_model = xgb.XGBClassifier(
    n_estimators=300,
    max_depth=4,
    learning_rate=0.05,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    n_jobs=-1,
    eval_metric="logloss"
)
xgb_model.fit(X_train, y_train)


# Convert sparse to dense if needed
X_test_dense = X_test.toarray() if hasattr(X_test, "toarray") else X_test

# Computing SHAP (TreeExplainer)
print("\nComputing SHAP values ...")

# Convert sparse matrices to dense arrays if needed
X_train_dense = X_train.toarray() if hasattr(X_train, "toarray") else X_train
X_test_dense  = X_test.toarray()  if hasattr(X_test, "toarray")  else X_test

# Use XGBoost built-in SHAP computation
booster = xgb_model.get_booster()

# Ensure feature names are strings
feature_names = [str(f) for f in feature_names]
feature_names = [str(f).replace("[", "(").replace("]", ")").replace("<", "_lt_").replace(">", "_gt_") for f in feature_names] # remove unsupported chars

# Compute SHAP contributions
shap_contrib = booster.predict(
    xgb.DMatrix(X_test_dense, feature_names=feature_names),
    pred_contribs=True
)

shap_matrix = shap_contrib[:, :-1] # drop the last column (bias term)

# Compute the mean absolute values 
importance_df = (
    pd.DataFrame({
        "feature": feature_names,
        "mean_abs_shap": np.abs(shap_matrix).mean(axis=0)
    })
    .sort_values("mean_abs_shap", ascending=False))

# Aggregate one-hot encoded features
agg_df = (
    importance_df
    .assign(base_feature=importance_df["feature"]
            .str.replace(r"^(cat__|num__)", "", regex=True)
            .str.replace(r"_[^_]+$", "", regex=True))
    .groupby("base_feature", as_index=False)["mean_abs_shap"]
    .mean()
    .sort_values("mean_abs_shap", ascending=False)
).reset_index(drop=True)

# Save results
importance_df.to_csv("feature_importance_model.csv", index=False)
agg_df.to_csv("feature_importance_model_grouped.csv", index=False)
print("Saved model-based feature scores -> feature_importance_model.csv")
print("Saved grouped (original-level) SHAP scores -> feature_importance_model_grouped.csv")

# Visualize
plt.figure(figsize=(8, 6))
top_df = agg_df.head(10)[::-1]
sns.barplot(
    data=top_df,
    x="mean_abs_shap",
    y="base_feature",
    color="steelblue"
)
plt.xlabel("Mean(|SHAP value|)")
plt.ylabel("Feature")
plt.title("Feature Importance (XGBoost SHAP, Grouped by Base Feature)")
plt.tight_layout()
plt.savefig("shap_summary_grouped.png", dpi=300)
print("Saved grouped SHAP summary plot -> shap_summary_grouped.png")


# 3.Comparison Plot
comparison_df = pd.merge(
    classical_df[["variable", "-log10(p)"]],
    agg_df.rename(columns={"base_feature": "variable", "mean_abs_shap": "SHAP"}),
    on="variable",
    how="inner"
)

# Normalize each metric to 0-1 scale for easier visual comparison
comparison_df["p_norm"] = comparison_df["-log10(p)"] / comparison_df["-log10(p)"].max()
comparison_df["shap_norm"] = comparison_df["SHAP"] / comparison_df["SHAP"].max()

# Melt for plotting
plot_df = comparison_df.melt(
    id_vars="variable",
    value_vars=["p_norm", "shap_norm"],
    var_name="Method",
    value_name="Normalized_Score"
)
plt.figure(figsize=(7,6))
sns.scatterplot(
    data=comparison_df,
    x="-log10(p)",
    y="SHAP",
    hue="variable",
    s=100
)
plt.xlabel("Classical Importance (-log10 p)")
plt.ylabel("Model-based Importance (mean |SHAP|)")
plt.title("Correlation between Classical and SHAP Feature Importance")
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', title="Feature")
plt.tight_layout()
plt.savefig("comparison_scatter.png", dpi=300)
print("Saved scatter comparison plot -> comparison_scatter.png")


# Summary
print("\n == Top 10 by χ² == ")
print(classical_df[["variable"]].iloc[1:11].to_string(index=True, header=False))

print("\n == Top 10 by SHAP == ")
print(agg_df[["base_feature"]].iloc[1:11].to_string(index=True, header=False))