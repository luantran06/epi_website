# Multi-dimensional Observation of Subgroups And Influential Characteristics in Diabetes
This repository contains the full pipeline for preprocessing, feature selection, modeling, subgroup analysis, forecasting, and visualization for our diabetes risk stratification project using the 2024 BRFSS dataset.
## Description
This project builds an end-to-end machine learning workflow to:

- Clean and preprocess BRFSS survey data  
- Perform feature selection using Chi-square tests and SHAP  
- Train predictive models (Logistic Regression, Random Forest, XGBoost)  
- Analyze subgroup-specific risk patterns across age and income  
- Forecast diabetes prevalence using advanced time-series methods  
- Generate all visualizations used in the final report/poster

All scripts are modular and can be run independently or in sequence.

## Installation
For installation, clone the project's GitHub repository to a local machine. Ensure recent Python installation (e.g. >= 3.8.20), pip, and Jupyter Notebook are installed.
```
pip install -r requirements.txt
```

## Execution

1. Preprocessing : Clean the raw BRFSS dataset and produces the cleaned CSV used for all downstream tasks.

   ```
   python preprocessing.py
   ```

3. Exploratory Data Analysis : Open the Jupyter Notebook and explore data using the cleaned CSV.

   run EDA.ipynb with *****_cleaned.csv

4. Feature Selection : Runs Chi-square tests + SHAP to rank the most important predictors.

   ```
   python feature_selection.py
   ```

6. Modeling Pipeline : Trains all machine learning models and computes subgroup specific SHAP values.
   
   ```
   python modeling_pipeline.py
   ```

8. Plot Generation : Creates all summary figures for SHAP analysis.
   ```
   python plots.py
   ```

For further exploration, we forecasted diabetes prevalence across the lifespan using polynomial regression, spline smoothing, ARIMA-style autoregression, and Prophet-style decomposition, achieving highly accurate predictions with average errors below 3%.

The folder `sub_group/` contains forecasting-related scripts, including
Age-specific transition forecasting
Income-stratified prevalence trajectories
Model performance comparisons
Polynomial, spline, ARIMA-style, and Prophet-style results.

These scripts reproduce the results presented in:
- Age Progression
- Forecasting Models
- Income-stratified trajectories
- Transfer learning across age groups
You can run scripts individually inside `sub_group/` as needed.


## File Description 
- preprocessing.py : preprocessing the raw dataset
- feature_selection.py : feature selection using two different approaches
- modeling_pipeline.py : main subgroup specific SHAP analysis
- run_all_forecasting.py : forecasting analysis
- EDA.ipynb : exploratory data analysis
- sub_group/ : contains codes to reproduce forecasting results
- DOC/ : contains our final report
- DIABETES_ANALYSIS_GUIDE.md : meta data and description of each column in our dataset
  

## Data Description

**Source**: BRFSS 2024 (CDC's annual health survey)
- 457,670 people surveyed
- 133,529 people with complete data used in analysis
- 23 risk factors analyzed (age, income, BMI, healthcare access, lifestyle, etc.)
- Features include :
  - Demographic : age, sex, race, income, education
  - Clinical : BMI, general health, comorbities
  - Behavioral : exercise, smoking, alcohol
  - Healthcare Access : insurance, doctor access, last checkup
  - Mental health : depression diagnosis, mental health days
  - Social Determinants : food insecurity, financial stress, bil-paying confidence



